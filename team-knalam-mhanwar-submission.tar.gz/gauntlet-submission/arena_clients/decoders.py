"""Deterministic decoders for "encrypted" data found in challenges and tool output.

LLMs are unreliable at base64, XOR, or Caesar by eye; these do it exactly.
``auto_decode`` tries every transform (and chains of them) and ranks the
results by how much they look like readable text, so the explorer can hand a
model the plaintext instead of the blob.
"""

from __future__ import annotations

import base64
import binascii
import codecs
import gzip
import html
import json
import re
import string
import zlib
from typing import Callable
from urllib.parse import unquote

MORSE = {
    ".-": "A", "-...": "B", "-.-.": "C", "-..": "D", ".": "E", "..-.": "F", "--.": "G",
    "....": "H", "..": "I", ".---": "J", "-.-": "K", ".-..": "L", "--": "M", "-.": "N",
    "---": "O", ".--.": "P", "--.-": "Q", ".-.": "R", "...": "S", "-": "T", "..-": "U",
    "...-": "V", ".--": "W", "-..-": "X", "-.--": "Y", "--..": "Z", "-----": "0",
    ".----": "1", "..---": "2", "...--": "3", "....-": "4", ".....": "5", "-....": "6",
    "--...": "7", "---..": "8", "----.": "9", ".-.-.-": ".", "--..--": ",", "..--..": "?",
    "-.-.--": "!", "-..-.": "/", "-.--.": "(", "-.--.-": ")", "---...": ":", "-...-": "=",
    ".-.-.": "+", "-....-": "-", ".-..-.": '"', ".--.-.": "@", "..--.-": "_",
}

# Letter frequencies of English text, for ranking Caesar/XOR candidates.
_ENGLISH_FREQ = {
    "e": 12.7, "t": 9.1, "a": 8.2, "o": 7.5, "i": 7.0, "n": 6.7, "s": 6.3, "h": 6.1,
    "r": 6.0, "d": 4.3, "l": 4.0, "c": 2.8, "u": 2.8, "m": 2.4, "w": 2.4, "f": 2.2,
    "g": 2.0, "y": 2.0, "p": 1.9, "b": 1.5, "v": 1.0, "k": 0.8, "j": 0.15, "x": 0.15,
    "q": 0.1, "z": 0.07,
}
_COMMON_WORDS = frozenset(
    "the be to of and a in that have i it for not on with he as you do at this but his by "
    "from they we say her she or an will my one all would there their what so up out if "
    "about who get which go me when make can like time no just him know take is are was "
    "were code key password answer secret flag next call tool use value token find hidden "
    "message access vault data file id number name level unlock door open".split()
)
_PRINTABLE = set(string.printable)


_COMMON_BIGRAMS = frozenset(
    "th he in er an re on at en nd ti es or te of ed is it al ar st to nt ng se ha as ou io le "
    "ve co me de hi ri ro ic ne ea ra ce li ch ll be ma si om ur".split()
)
_OK_PUNCT = set(" .,'\"!?-:;()_/\n\t")
_MILD_PUNCT = set("{}[]=#@&%$+*<>|~^`\\")


def readability(text: str) -> float:
    """0..1: how much ``text`` looks like human-readable (English-ish) text."""
    if not text:
        return 0.0
    sample = text[:2000]
    n = len(sample)
    printable = sum(ch in _PRINTABLE for ch in sample) / n
    if printable < 0.95:
        return printable * 0.2
    odd = sum(
        0.0 if ch.isalnum() or ch in _OK_PUNCT else 0.5 if ch in _MILD_PUNCT else 1.0
        for ch in sample
    ) / n
    letters = [ch.lower() for ch in sample if ch.isalpha()]
    if len(letters) < 3:
        # Digits/punctuation only (e.g. a PIN): plausible but weak evidence.
        return 0.35 if sample.strip() and odd < 0.2 else 0.0
    alpha_ratio = len(letters) / max(1, sum(not ch.isspace() for ch in sample))
    pairs = [a + b for w in re.findall(r"[a-z]+", sample.lower()) for a, b in zip(w, w[1:])]
    bigram = min(1.0, (sum(p in _COMMON_BIGRAMS for p in pairs) / len(pairs)) / 0.45) if pairs else 0.0
    words = re.findall(r"[a-z]+", sample.lower())
    common = min(1.0, 2.5 * sum(w in _COMMON_WORDS for w in words) / max(1, len(words)))
    spaces = sample.count(" ") / n
    space_bonus = 0.1 if 0.05 <= spaces <= 0.35 else 0.0
    # Real text uses many different letters; XOR/shift artefacts often don't.
    diversity = min(1.0, len(set(letters)) / min(10.0, max(3.0, len(letters) / 2)))
    score = diversity * (0.45 * bigram + 0.35 * common + 0.1 * min(1.0, alpha_ratio) + space_bonus) - 2.0 * odd
    return max(0.0, min(1.0, score))


def _as_text(data: bytes) -> str | None:
    for encoding in ("utf-8",):
        try:
            text = data.decode(encoding)
        except UnicodeDecodeError:
            continue
        if text and sum(ch in _PRINTABLE or ord(ch) > 127 for ch in text) / len(text) > 0.9:
            return text
    return None


def _maybe_decompress(data: bytes) -> bytes:
    if data[:2] == b"\x1f\x8b":
        try:
            return gzip.decompress(data)
        except Exception:
            return data
    if data[:1] == b"\x78":
        try:
            return zlib.decompress(data)
        except Exception:
            return data
    return data


def b64_bytes(text: str) -> bytes | None:
    compact = re.sub(r"\s+", "", text)
    if len(compact) < 4 or not re.fullmatch(r"[A-Za-z0-9+/_-]+={0,2}", compact):
        return None
    padded = compact + "=" * (-len(compact) % 4)
    try:
        if "-" in compact or "_" in compact:
            return base64.urlsafe_b64decode(padded)
        return base64.b64decode(padded, validate=True)
    except (binascii.Error, ValueError):
        return None


def from_base64(text: str) -> str | None:
    data = b64_bytes(text)
    return _as_text(_maybe_decompress(data)) if data else None


def from_base32(text: str) -> str | None:
    compact = re.sub(r"\s+", "", text).upper()
    if len(compact) < 8 or not re.fullmatch(r"[A-Z2-7]+=*", compact):
        return None
    try:
        return _as_text(base64.b32decode(compact + "=" * (-len(compact) % 8)))
    except (binascii.Error, ValueError):
        return None


def hex_bytes(text: str) -> bytes | None:
    compact = re.sub(r"(0x|\\x|[\s:,-])", "", text, flags=re.IGNORECASE)
    if len(compact) < 4 or len(compact) % 2 or not re.fullmatch(r"[0-9a-fA-F]+", compact):
        return None
    return bytes.fromhex(compact)


def from_hex(text: str) -> str | None:
    data = hex_bytes(text)
    return _as_text(_maybe_decompress(data)) if data else None


def from_binary(text: str) -> str | None:
    groups = re.findall(r"[01]+", text)
    if not groups or re.sub(r"[01\s,]", "", text):
        return None
    bits = "".join(groups)
    width = 8 if all(len(g) == 8 for g in groups) or len(groups) == 1 else len(groups[0])
    if width not in (7, 8) or len(bits) % width:
        return None
    return _as_text(bytes(int(bits[i:i + width], 2) for i in range(0, len(bits), width)))


def from_decimal_codes(text: str) -> str | None:
    nums = re.findall(r"\d+", text)
    if len(nums) < 3 or re.sub(r"[\d\s,;]", "", text):
        return None
    values = [int(n) for n in nums]
    if not all(32 <= v < 127 or v in (9, 10, 13) for v in values):
        return None
    return "".join(chr(v) for v in values)


def from_morse(text: str) -> str | None:
    stripped = text.strip()
    if not stripped or re.sub(r"[.\-\s/|_·•−]", "", stripped):
        return None
    normalized = stripped.replace("·", ".").replace("•", ".").replace("−", "-").replace("_", "-")
    words = re.split(r"\s*[/|]\s*|\s{3,}", normalized)
    out = []
    for word in words:
        letters = [MORSE.get(code) for code in word.split()]
        if not letters or None in letters:
            return None
        out.append("".join(letters))
    return " ".join(out)


def caesar(text: str, shift: int) -> str:
    def rot(ch: str) -> str:
        if "a" <= ch <= "z":
            return chr((ord(ch) - 97 - shift) % 26 + 97)
        if "A" <= ch <= "Z":
            return chr((ord(ch) - 65 - shift) % 26 + 65)
        return ch
    return "".join(rot(ch) for ch in text)


def best_caesar(text: str) -> tuple[int, str]:
    """(shift, plaintext) with the most English-looking result; shift 0 included."""
    return max(((s, caesar(text, s)) for s in range(26)), key=lambda item: readability(item[1]))


def atbash(text: str) -> str:
    def flip(ch: str) -> str:
        if "a" <= ch <= "z":
            return chr(219 - ord(ch))
        if "A" <= ch <= "Z":
            return chr(155 - ord(ch))
        return ch
    return "".join(flip(ch) for ch in text)


def vigenere(text: str, key: str, decrypt: bool = True) -> str:
    shifts = [ord(ch.lower()) - 97 for ch in key if ch.isalpha()]
    if not shifts:
        return text
    out, i = [], 0
    for ch in text:
        if ch.isalpha():
            base = 65 if ch.isupper() else 97
            shift = shifts[i % len(shifts)] * (-1 if decrypt else 1)
            out.append(chr((ord(ch) - base + shift) % 26 + base))
            i += 1
        else:
            out.append(ch)
    return "".join(out)


def xor_bytes(data: bytes, key: bytes) -> bytes:
    return bytes(b ^ key[i % len(key)] for i, b in enumerate(data))


def _cipher_bytes(text: str) -> bytes:
    """Bytes behind ``text``: hex or base64 when it parses as such, else UTF-8."""
    return hex_bytes(text) or b64_bytes(text) or text.encode("utf-8")


def xor_decrypt(text: str, key: str) -> str | None:
    data = _cipher_bytes(text)
    key_bytes = hex_bytes(key) if re.fullmatch(r"(0x)?[0-9a-fA-F]{2,}", key.strip()) and len(key.strip()) % 2 == 0 else None
    candidates = [key.encode("utf-8")] + ([key_bytes] if key_bytes else [])
    if key.strip().isdigit() and int(key) < 256:
        candidates.append(bytes([int(key)]))
    best = None
    for kb in candidates:
        plain = _as_text(xor_bytes(data, kb))
        if plain and (best is None or readability(plain) > readability(best)):
            best = plain
    return best


def best_single_byte_xor(text: str) -> tuple[int, str] | None:
    data = _cipher_bytes(text)
    scored = []
    for k in range(1, 256):
        plain = _as_text(xor_bytes(data, bytes([k])))
        if plain:
            scored.append((readability(plain), k, plain))
    if not scored:
        return None
    _, k, plain = max(scored)
    return k, plain


def jwt_payload(text: str) -> str | None:
    parts = text.strip().split(".")
    if len(parts) != 3 or not all(parts[:2]):
        return None
    decoded = []
    for part in parts[:2]:
        raw = b64_bytes(part)
        if raw is None:
            return None
        decoded.append(raw.decode("utf-8", "replace"))
    try:
        json.loads(decoded[1])
    except ValueError:
        return None
    return f"header={decoded[0]} payload={decoded[1]}"


def _rot47(text: str) -> str:
    return "".join(chr(33 + (ord(ch) + 14) % 94) if 33 <= ord(ch) <= 126 else ch for ch in text)


# Keyless transforms tried by auto_decode, in order.
TRANSFORMS: dict[str, Callable[[str], str | None]] = {
    "base64": from_base64,
    "base32": from_base32,
    "hex": from_hex,
    "binary": from_binary,
    "decimal": from_decimal_codes,
    "morse": from_morse,
    "jwt": jwt_payload,
    "url": lambda t: unquote(t) if "%" in t and unquote(t) != t else None,
    "html": lambda t: html.unescape(t) if "&" in t and html.unescape(t) != t else None,
    "unicode_escape": lambda t: codecs.decode(t, "unicode_escape") if "\\u" in t or "\\x" in t else None,
    "rot13": lambda t: codecs.decode(t, "rot13") if re.search(r"[A-Za-z]", t) else None,
    "rot47": lambda t: _rot47(t) if re.search(r"[!-~]", t) else None,
    "atbash": lambda t: atbash(t) if re.search(r"[A-Za-z]", t) else None,
    "reverse": lambda t: t[::-1] if len(t) > 3 else None,
}


def _caesar_candidate(text: str) -> str | None:
    if not re.search(r"[A-Za-z]{3}", text):
        return None
    shift, plain = best_caesar(text)
    return plain if shift not in (0, 13) else None


def _xor_candidate(text: str) -> str | None:
    if not (hex_bytes(text) or b64_bytes(text)):
        return None
    found = best_single_byte_xor(text)
    return found[1] if found else None


TRANSFORMS["caesar"] = _caesar_candidate
TRANSFORMS["xor1"] = _xor_candidate
_GUESSING = {"caesar", "xor1", "rot47", "atbash"}
_STRUCTURAL = {"base64", "base32", "hex", "binary", "decimal", "morse", "jwt", "url", "html", "unicode_escape"}


def auto_decode(text: str, *, depth: int = 3, limit: int = 5) -> list[tuple[str, str, float]]:
    """Ranked (chain, plaintext, score) candidates; chains like ``base64>rot13``.

    Only candidates more readable than the input are kept, so plain English
    yields nothing.
    """
    text = str(text or "").strip()
    if not text:
        return []
    base_score = readability(text)
    seen = {text}
    frontier = [("", text)]
    results: list[tuple[str, str, float]] = []
    for _ in range(depth):
        next_frontier = []
        for chain, current in frontier:
            for name, fn in TRANSFORMS.items():
                if chain.endswith(name) and name in {"reverse", "rot13", "atbash", "rot47"}:
                    continue  # self-inverse
                # Brute-forced keys fit noise on short strings; only try them
                # on the raw input or right after unwrapping base64/hex.
                if name in _GUESSING and chain not in ("", "base64", "hex", "reverse"):
                    continue
                try:
                    out = fn(current)
                except Exception:
                    out = None
                if not out or out in seen or len(out) > 20000:
                    continue
                seen.add(out)
                new_chain = f"{chain}>{name}" if chain else name
                score = readability(out)
                # Strict formats (base64, hex, binary, Morse...) rarely parse by
                # accident, so a chain made only of them earns trust.
                if all(step in _STRUCTURAL for step in new_chain.split(">")) and score >= 0.15:
                    score = min(1.0, score + 0.3)
                next_frontier.append((new_chain, out))
                results.append((new_chain, out, score))
        # Keep the search tractable: expand only the promising branches.
        next_frontier.sort(key=lambda item: readability(item[1]), reverse=True)
        frontier = next_frontier[:8]
    # A longer chain must be clearly better to beat a shorter one.
    ranked = sorted(
        (r for r in results if r[2] > base_score + 0.1 and r[2] >= 0.4),
        key=lambda r: r[2] - 0.08 * r[0].count(">"),
        reverse=True,
    )
    return ranked[:limit]


_ENCODED_SPAN = re.compile(
    r"(?<![A-Za-z0-9+/=])("
    r"[A-Za-z0-9+/]{16,}={0,2}"           # base64
    r"|[A-Za-z0-9_-]{20,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]*"  # jwt
    r"|(?:0x)?[0-9a-fA-F]{16,}"           # hex
    r"|(?:[01]{7,8}[\s,]+){3,}[01]{7,8}"  # binary
    r"|(?:[.\-]{1,6}[ /]+){4,}[.\-]{1,6}"  # morse
    r")(?![A-Za-z0-9+/=])"
)


def find_encoded_spans(text: str, *, limit: int = 6) -> list[str]:
    """Substrings of ``text`` that look like encoded payloads."""
    spans: list[str] = []
    for match in _ENCODED_SPAN.finditer(str(text or "")):
        span = match.group(1).strip()
        # Long plain words or identifiers are not payloads.
        if span.isalpha() and (span.islower() or span.isupper()):
            continue
        if span not in spans:
            spans.append(span)
        if len(spans) >= limit:
            break
    return spans


def _string_leaves(text: str) -> list[str]:
    """String values inside a JSON payload (or the text itself when not JSON)."""
    try:
        value = json.loads(text)
    except (ValueError, TypeError):
        return [text]
    leaves: list[str] = []

    def walk(node: object) -> None:
        if isinstance(node, str):
            leaves.append(node)
        elif isinstance(node, dict):
            for item in node.values():
                walk(item)
        elif isinstance(node, list):
            for item in node:
                walk(item)

    walk(value)
    return leaves


def annotate(text: str, *, max_notes: int = 4) -> list[str]:
    """Readable decodings of encoded spans inside ``text`` (for tool output)."""
    notes: list[str] = []
    candidates: list[str] = []
    for leaf in _string_leaves(str(text or ""))[:60]:
        leaf = leaf.strip()
        if not leaf or len(leaf) > 4000:
            continue
        # A whole value can be one cipher (Caesar text, Morse with spaces...).
        if len(leaf) >= 8 and readability(leaf) < 0.4:
            candidates.append(leaf)
        candidates.extend(span for span in find_encoded_spans(leaf) if span != leaf)
    seen: set[str] = set()
    for span in candidates:
        if span in seen:
            continue
        seen.add(span)
        decoded = auto_decode(span, depth=3, limit=1)
        # Hints are shown unasked, so only confident ones: junk misleads.
        if decoded and decoded[0][2] >= 0.55:
            chain, plain, _score = decoded[0]
            notes.append(f"{span[:40]}{'…' if len(span) > 40 else ''} --{chain}--> {plain[:500]}")
        if len(notes) >= max_notes:
            break
    return notes


def looks_encoded(text: str) -> bool:
    """True when ``text`` carries a payload that decodes to something readable."""
    return bool(annotate(text, max_notes=1))


def decode(text: str, method: str = "auto", key: str = "") -> str:
    """Tool entry point: decode ``text`` with ``method`` (default: try everything)."""
    text = str(text or "")
    method = (method or "auto").strip().lower()
    key = str(key or "")
    try:
        if method in ("auto", ""):
            if key:
                keyed = [
                    ("xor", xor_decrypt(text, key)),
                    ("vigenere", vigenere(text, key)),
                ]
                lines = [f"{name}(key={key!r}): {out}" for name, out in keyed if out]
                lines += [f"{c}: {p}" for c, p, _ in auto_decode(text)]
                return "\n".join(lines) or "no readable decoding found"
            found = auto_decode(text)
            if not found:
                return "no readable decoding found (try a method with a key: xor, vigenere, caesar)"
            return "\n".join(f"{chain} (score {score:.2f}): {plain}" for chain, plain, score in found)
        if method == "caesar":
            if key.strip().lstrip("-").isdigit():
                return caesar(text, int(key))
            shift, plain = best_caesar(text)
            return f"best shift {shift}: {plain}"
        if method == "caesar_all":
            return "\n".join(f"{s}: {caesar(text, s)}" for s in range(1, 26))
        if method == "vigenere":
            return vigenere(text, key) if key else "vigenere needs key"
        if method == "vigenere_encrypt":
            return vigenere(text, key, decrypt=False) if key else "vigenere needs key"
        if method == "xor":
            if key:
                return xor_decrypt(text, key) or "xor with that key gave unreadable bytes"
            found = best_single_byte_xor(text)
            return f"best single-byte key {found[0]}: {found[1]}" if found else "no readable xor"
        if method in TRANSFORMS:
            out = TRANSFORMS[method](text)
            return out if out is not None else f"input is not valid {method}"
        if method in ("base64_encode", "b64encode"):
            return base64.b64encode(text.encode()).decode()
        if method == "hex_encode":
            return text.encode().hex()
        if method == "sha256":
            import hashlib
            return hashlib.sha256(text.encode()).hexdigest()
        if method == "md5":
            import hashlib
            return hashlib.md5(text.encode()).hexdigest()
    except Exception as exc:  # malformed input must not crash the agent
        return f"decode error: {type(exc).__name__}: {exc}"
    return f"unknown method {method!r}; methods: auto, caesar, caesar_all, vigenere, xor, " + ", ".join(TRANSFORMS)


DECODE_METHODS = ["auto", "caesar", "caesar_all", "vigenere", "vigenere_encrypt", "xor", *TRANSFORMS, "base64_encode", "hex_encode", "sha256", "md5"]
