"""Autonomous MCP explorer: an LLM tool-calling loop over an unknown server.

The Practice puzzles hand the agent everything it needs in the challenge and
its clues. The live Black Box does not: tools are undocumented, some appear
only after others are called, data is encoded, and one tool's output is the
next one's input. ``Explorer`` gives a model every discovered MCP tool,
resource, and prompt as callable functions, plus local helpers (exact
decoders, a Python sandbox) and a ``final_answer`` function, and runs until
the model answers or the time budget runs out.

It never submits: the caller owns submission, so a hidden ``*submit*`` tool
can't burn the one official answer.
"""

from __future__ import annotations

import asyncio
import json
import os
import re
import subprocess
import sys
import tempfile
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Awaitable, Callable

from . import decoders

# Tool names the model must not call: the caller submits; re-registering on
# Practice wipes the run.
_BLOCKED_TOOL = re.compile(r"submit|register|disconnect", re.IGNORECASE)
# Read-only-looking tools worth calling once up front, when they need no input.
_PROBE_TOOL = re.compile(
    r"(^|[._-])(list|help|info|about|describe|manifest|readme|catalog|index|hint|hints|"
    r"status|overview|schema|capabilit|guide|instructions|menu|directory|map|inventory)",
    re.IGNORECASE,
)
_DATA_URI = re.compile(r"data:[\w/+.-]+;base64,[A-Za-z0-9+/=]{200,}")
_TOOL_RESULT_CHARS = 6000
# OpenAI-style APIs reject more than 128 functions; the rest stay reachable
# through call_tool_raw (the inventory lists every tool).
_MAX_FUNCTIONS = 120
_HISTORY_CHARS = 90000

FINAL_ANSWER = "final_answer"


@dataclass
class ExplorerResult:
    answer: str = ""
    reason: str = ""
    model: str = ""
    steps: int = 0
    tools_used: list[str] = field(default_factory=list)
    usage: dict[str, int] = field(default_factory=lambda: {"prompt_tokens": 0, "completion_tokens": 0, "total_tokens": 0})
    transcript: list[dict[str, Any]] = field(default_factory=list)
    images: dict[str, str] = field(default_factory=dict)
    timed_out: bool = False
    elapsed_ms: int = 0


def _expand_json_strings(text: str) -> str:
    """JSON with long string values (logs, CSV) re-rendered so each line is greppable."""
    try:
        data = json.loads(text)
    except (ValueError, TypeError):
        return text
    parts: list[str] = []

    def walk(node: Any, path: str) -> None:
        if isinstance(node, dict):
            for k, v in node.items():
                walk(v, f"{path}.{k}" if path else str(k))
        elif isinstance(node, list):
            for i, v in enumerate(node):
                walk(v, f"{path}[{i}]")
        elif isinstance(node, str) and "\n" in node:
            parts.append(f"[{path}]")
            parts.extend(node.splitlines())
        else:
            parts.append(f"{path}: {json.dumps(node, ensure_ascii=False)}")

    walk(data, "")
    return "\n".join(parts)


def _sanitize_name(name: str, taken: set[str]) -> str:
    base = re.sub(r"[^a-zA-Z0-9_-]", "_", name)[:60] or "tool"
    candidate, i = base, 2
    while candidate in taken:
        candidate = f"{base[:57]}_{i}"
        i += 1
    taken.add(candidate)
    return candidate


def _clean_schema(schema: Any, *, drop: tuple[str, ...] = ("agent_id",)) -> dict[str, Any]:
    """An OpenAI-acceptable JSON schema for an MCP tool's inputSchema."""
    if not isinstance(schema, dict):
        return {"type": "object", "properties": {}}
    cleaned = json.loads(json.dumps(schema))  # deep copy, JSON-safe
    cleaned.pop("$schema", None)
    cleaned.pop("title", None)
    cleaned["type"] = "object"
    props = cleaned.get("properties")
    if not isinstance(props, dict):
        props = {}
    for key in drop:
        props.pop(key, None)
    cleaned["properties"] = props
    # Black-box schemas can be wrong; let the model pass what an error asks for.
    cleaned["additionalProperties"] = True
    required = [r for r in cleaned.get("required") or [] if r in props]
    if required:
        cleaned["required"] = required
    else:
        cleaned.pop("required", None)
    return cleaned


def _schema_summary(schema: Any) -> str:
    if not isinstance(schema, dict):
        return "()"
    props = schema.get("properties") or {}
    required = set(schema.get("required") or [])
    parts = []
    for name, spec in props.items():
        if name == "agent_id":
            continue
        typ = spec.get("type", "?") if isinstance(spec, dict) else "?"
        parts.append(f"{name}{'' if name in required else '?'}: {typ}")
    return "(" + ", ".join(parts) + ")"


def _required_args(schema: Any) -> list[str]:
    if not isinstance(schema, dict):
        return []
    return [r for r in schema.get("required") or [] if r != "agent_id"]


def extract_answer(raw: str) -> str:
    """The text after the last ``ANSWER:`` marker (JSON kept whole)."""
    cleaned = re.sub(r"<think>.*?(?:</think>|$)", "", raw or "", flags=re.DOTALL).strip()
    found = ""
    for match in re.finditer(r"^[ \t]*(?:final answer|answer)[ \t]*:[ \t]*(.*?)[ \t]*$", cleaned, re.IGNORECASE | re.MULTILINE):
        tail = cleaned[match.start(1):].lstrip()
        if tail[:1] in ("{", "["):
            try:
                value, _ = json.JSONDecoder().raw_decode(tail)
                found = json.dumps(value, ensure_ascii=False, separators=(",", ":"))
                continue
            except ValueError:
                pass
        candidate = match.group(1).strip().strip("`\"'")
        if candidate:
            found = candidate
    return found


_MARKUP = re.compile(r"</?tool_call|<\|[a-z_]+\|>|</?function|\"tool_calls\"|^\s*</?\w+>\s*$", re.IGNORECASE)


def _usable_answer(answer: str) -> bool:
    """False for empty answers and leaked tool-call markup."""
    text = str(answer or "").strip()
    return bool(text) and not _MARKUP.search(text)


class _Fn:
    def __init__(self, name: str, arguments: str) -> None:
        self.name, self.arguments = name, arguments


class _Call:
    def __init__(self, call_id: str, name: str, arguments: str) -> None:
        self.id, self.function = call_id, _Fn(name, arguments)


def _textual_tool_calls(content: str, step: int) -> list[_Call]:
    """Tool calls some models write as text (<tool_call>{...}</tool_call>) instead of natively."""
    calls = []
    for i, match in enumerate(re.finditer(r"<tool_call>\s*(\{.*?\})\s*(?:</tool_call>|$)", content or "", re.DOTALL)):
        try:
            data = json.loads(match.group(1))
        except ValueError:
            continue
        name = str(data.get("name") or "")
        args = data.get("arguments", data.get("parameters", {}))
        if name:
            calls.append(_Call(f"text_{step}_{i}", name, args if isinstance(args, str) else json.dumps(args)))
    return calls


_PY_DENY = re.compile(r"\b(subprocess|socket|shutil|requests|urllib|http\.client|ctypes|multiprocessing)\b|os\.(system|remove|unlink|rmdir|exec|spawn|kill|fork)")


def run_python(code: str, timeout_s: float = 6.0) -> str:
    """Run a short computation in an isolated interpreter; returns stdout/stderr."""
    code = str(code or "")
    if _PY_DENY.search(code):
        return "refused: the sandbox allows pure computation only (no processes, network, or file deletion)"
    with tempfile.TemporaryDirectory() as tmp:
        try:
            proc = subprocess.run(
                [sys.executable, "-I", "-c", code],
                capture_output=True,
                text=True,
                timeout=timeout_s,
                cwd=tmp,
                env={"PATH": os.environ.get("PATH", ""), "PYTHONIOENCODING": "utf-8"},
            )
        except subprocess.TimeoutExpired:
            return f"timeout after {timeout_s}s"
    out = (proc.stdout or "")[-4000:]
    err = (proc.stderr or "")[-1500:]
    if not out and not err:
        return "(no output — use print())"
    return out + (f"\n[stderr]\n{err}" if err else "")


LOCAL_TOOLS: list[dict[str, Any]] = [
    {
        "type": "function",
        "function": {
            "name": "decode_data",
            "description": (
                "Exactly decode/decrypt text. method='auto' tries base64/base32/hex/binary/decimal/morse/"
                "url/html/jwt/rot13/rot47/atbash/reverse/caesar/single-byte-xor and chains of them, ranked by "
                "readability. With a key: method='xor' or 'vigenere' (or 'auto' + key to try both). "
                "Also 'caesar' (key=shift, or no key to brute force), 'caesar_all', base64_encode, hex_encode, sha256, md5."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "text": {"type": "string", "description": "The encoded data, verbatim."},
                    "method": {"type": "string", "enum": decoders.DECODE_METHODS},
                    "key": {"type": "string", "description": "Key or shift, when the cipher needs one."},
                },
                "required": ["text"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "run_python",
            "description": (
                "Run a short Python 3 snippet and return what it prints. Use for exact arithmetic, "
                "sorting/filtering data, date math, string manipulation, or custom ciphers. Always print() the result."
            ),
            "parameters": {
                "type": "object",
                "properties": {"code": {"type": "string"}},
                "required": ["code"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "call_tool_raw",
            "description": (
                "Call any MCP tool by its exact server name with any arguments. Use when a tool's schema is wrong "
                "(an error asks for a different argument), or to try a tool name you saw mentioned but is not listed."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "name": {"type": "string", "description": "Exact MCP tool name, e.g. records.get"},
                    "arguments": {"type": "object", "additionalProperties": True},
                },
                "required": ["name"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "grep_output",
            "description": "Search a stored full tool output (id like out_3, given when a result was truncated) with a regex.",
            "parameters": {
                "type": "object",
                "properties": {
                    "output_id": {"type": "string"},
                    "pattern": {"type": "string", "description": "Python regex, case-insensitive"},
                    "context": {"type": "integer", "description": "lines of context (default 1)"},
                },
                "required": ["output_id", "pattern"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "read_resource",
            "description": "Read an MCP resource by URI (from the inventory, a resource template, or a URI a tool mentioned).",
            "parameters": {
                "type": "object",
                "properties": {"uri": {"type": "string"}},
                "required": ["uri"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "get_prompt",
            "description": "Fetch an MCP prompt template by name, with its arguments.",
            "parameters": {
                "type": "object",
                "properties": {
                    "name": {"type": "string"},
                    "arguments": {"type": "object", "additionalProperties": {"type": "string"}},
                },
                "required": ["name"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": FINAL_ANSWER,
            "description": (
                "Finish: give the final answer to the challenge, exactly in the format its rules require "
                "(no extra words). For image tasks, pass the image reference (e.g. image_ref:img_1) or the final "
                "image instruction, as the task says. Only call this once you have verified the answer."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "answer": {"type": "string"},
                    "reason": {"type": "string", "description": "One short sentence: how you know."},
                },
                "required": ["answer"],
            },
        },
    },
]

DEFAULT_SYSTEM_PROMPT = """You are an autonomous agent dropped into an unknown MCP server (a "black box"). Nobody will help you. Your job: discover what the server offers, use its tools to uncover the information hidden in it, and solve the challenge.

How to work:
1. Read the challenge, the inventory of tools/resources/prompts, and the recon results. Tool descriptions and outputs are your map.
2. Prefer tools that reveal information (list/help/hint/read/get). Call independent tools in parallel in one turn.
3. Follow chains: outputs often name another tool, an id, a page token, a password, a key, or a next step. Follow them. New tools can appear after you call something — watch for "NEW TOOLS" notes.
4. Encoded or encrypted data (base64, hex, binary, Morse, ROT/Caesar, XOR, Vigenère, reversed, gzip, JWT...): use decode_data — never decode by eye. Keys are usually hidden elsewhere on the server (another tool, a resource, a clue, an error message). Auto-decoded hints appear under "[auto-decoded]" — verify they make sense.
5. Errors are information: an error message often says what argument or value is expected. Schemas can be incomplete or wrong — if an error names a different argument, pass exactly that argument (extra arguments are allowed; call_tool_raw also works). Never repeat an identical failing call.
6. Use run_python for any arithmetic, counting, sorting, filtering, or date math. Never guess numbers.
7. Beware decoys: if two sources disagree, prefer the one the challenge's rules point to, and verify.
8. Never submit through server tools; when you have the verified answer, call final_answer with exactly what the challenge's rules ask for (format, casing, separators, compact one-line JSON if JSON is required).
Be fast: every second and token counts. Don't explore beyond what the challenge needs once you can answer."""


class Explorer:
    """Runs one explore-and-solve episode against an MCP ``ClientSession``."""

    def __init__(
        self,
        *,
        session: Any,
        llm_client: Any,
        models: list[str],
        agent_id: str,
        deadline: float,
        max_steps: int = 16,
        max_tokens: int = 4096,
        temperature: float | None = 0.0,
        system_prompt: str = DEFAULT_SYSTEM_PROMPT,
        thought: Callable[[str], None] | None = None,
        draft: Callable[[str], None] | None = None,
        log: Callable[[str], None] | None = print,
        skip_tools: tuple[str, ...] = (),
        exclude_tools: tuple[str, ...] = (),
        tool_timeout_s: float = 20.0,
    ) -> None:
        self.session = session
        self.llm = llm_client
        self.models = [m for m in models if m]
        self.agent_id = agent_id
        self.deadline = deadline
        self.max_steps = max_steps
        self.max_tokens = max_tokens
        self.temperature = temperature
        self.system_prompt = system_prompt
        self._thought = thought or (lambda _msg: None)
        self._draft = draft or (lambda _msg: None)
        self._log = log or (lambda _msg: None)
        self.skip_tools = set(skip_tools)
        self.exclude_tools = set(exclude_tools)
        self.tool_timeout_s = tool_timeout_s
        self.tool_defs: dict[str, Any] = {}       # MCP name -> Tool
        self.fn_to_mcp: dict[str, str] = {}       # function name -> MCP name
        self._fn_names: set[str] = {t["function"]["name"] for t in LOCAL_TOOLS}
        self.resources: list[Any] = []
        self.resource_templates: list[Any] = []
        self.prompts: list[Any] = []
        self.result = ExplorerResult()
        self._call_cache: dict[str, str] = {}
        self._call_counts: dict[str, int] = {}
        self._outputs: dict[str, str] = {}

    # ---------- time ----------
    def time_left(self) -> float:
        return self.deadline - time.monotonic()

    # ---------- discovery ----------
    async def _list_tools(self) -> list[Any]:
        try:
            listed = await asyncio.wait_for(self.session.list_tools(), timeout=10)
            return list(listed.tools)
        except Exception as exc:
            self._log(f"   explorer: list_tools failed ({type(exc).__name__})")
            return []

    def _register_tools(self, tools: list[Any]) -> list[str]:
        new = []
        for tool in tools:
            name = str(getattr(tool, "name", "") or "")
            if not name or name in self.tool_defs:
                continue
            self.tool_defs[name] = tool
            if _BLOCKED_TOOL.search(name) or name in self.exclude_tools:
                continue
            fn = _sanitize_name(name, self._fn_names)
            self.fn_to_mcp[fn] = name
            new.append(name)
        return new

    async def _optional(self, coro, attr: str) -> list[Any]:
        try:
            listed = await asyncio.wait_for(coro, timeout=8)
            return list(getattr(listed, attr, []) or [])
        except Exception:
            return []  # servers may not implement resources/prompts

    async def discover(self) -> None:
        tools, resources, templates, prompts = await asyncio.gather(
            self._list_tools(),
            self._optional(self.session.list_resources(), "resources"),
            self._optional(self.session.list_resource_templates(), "resourceTemplates"),
            self._optional(self.session.list_prompts(), "prompts"),
        )
        self._register_tools(tools)
        self.resources, self.resource_templates, self.prompts = resources, templates, prompts

    def inventory_text(self) -> str:
        lines = ["TOOLS (call them as functions):"]
        items = list(self.fn_to_mcp.items())
        overflow = items[_MAX_FUNCTIONS - len(LOCAL_TOOLS):]
        if overflow:
            lines.insert(0, f"({len(overflow)} tools beyond the function limit are listed at the end; call them with call_tool_raw)")
        for fn, mcp_name in items[:_MAX_FUNCTIONS - len(LOCAL_TOOLS)]:
            tool = self.tool_defs[mcp_name]
            desc = re.sub(r"\s+", " ", str(getattr(tool, "description", "") or "")).strip()
            alias = f" [function {fn}]" if fn != mcp_name else ""
            lines.append(f"- {mcp_name}{alias}{_schema_summary(getattr(tool, 'inputSchema', None))}: {desc[:400]}")
        if overflow:
            lines.append("MORE TOOLS (call_tool_raw only): " + ", ".join(
                f"{m}{_schema_summary(getattr(self.tool_defs[m], 'inputSchema', None))}" for _, m in overflow
            ))
        hidden = [n for n in self.tool_defs if n not in self.fn_to_mcp.values()]
        if hidden:
            lines.append(f"(reserved for the runtime, do not need calling: {', '.join(hidden)})")
        if self.resources:
            lines.append("RESOURCES (read_resource):")
            for res in self.resources[:30]:
                lines.append(f"- {getattr(res, 'uri', '')} {getattr(res, 'name', '') or ''}: {str(getattr(res, 'description', '') or '')[:200]}")
        if self.resource_templates:
            lines.append("RESOURCE TEMPLATES (fill the {params}, then read_resource):")
            for tpl in self.resource_templates[:20]:
                lines.append(f"- {getattr(tpl, 'uriTemplate', '')}: {str(getattr(tpl, 'description', '') or '')[:200]}")
        if self.prompts:
            lines.append("PROMPTS (get_prompt):")
            for pr in self.prompts[:20]:
                args = ", ".join(str(getattr(a, "name", "")) for a in (getattr(pr, "arguments", None) or []))
                lines.append(f"- {getattr(pr, 'name', '')}({args}): {str(getattr(pr, 'description', '') or '')[:200]}")
        return "\n".join(lines)

    # ---------- execution ----------
    def _render_result(self, result: Any) -> str:
        parts: list[str] = []
        structured = getattr(result, "structuredContent", None)
        for item in getattr(result, "content", None) or []:
            kind = getattr(item, "type", "")
            if kind == "text":
                parts.append(str(getattr(item, "text", "")))
            elif kind == "image":
                ref = self._store_image(f"data:{getattr(item, 'mimeType', 'image/png')};base64,{getattr(item, 'data', '')}")
                parts.append(f"[image returned: {ref}]")
            elif kind == "resource":
                res = getattr(item, "resource", None)
                parts.append(str(getattr(res, "text", "") or f"[resource {getattr(res, 'uri', '')}]"))
            else:
                parts.append(str(item))
        if not parts and structured is not None:
            parts.append(json.dumps(structured, ensure_ascii=False, default=str))
        text = "\n".join(p for p in parts if p).strip()
        if getattr(result, "isError", False):
            text = f"ERROR: {text}"
        return self._shrink(text or "(empty result)")

    def _store_image(self, data_uri: str) -> str:
        ref = f"image_ref:img_{len(self.result.images) + 1}"
        self.result.images[ref] = data_uri
        return ref

    def _shrink(self, text: str) -> str:
        text = _DATA_URI.sub(lambda m: self._store_image(m.group(0)), text)
        if len(text) > _TOOL_RESULT_CHARS:
            out_id = f"out_{len(self._outputs) + 1}"
            self._outputs[out_id] = _expand_json_strings(text)
            text = (
                text[:_TOOL_RESULT_CHARS]
                + f"\n…[truncated {len(text) - _TOOL_RESULT_CHARS} of {len(text)} chars. Full output stored as {out_id}: "
                f"search it with grep_output(output_id='{out_id}', pattern=...)]"
            )
        return text

    def grep_output(self, output_id: str, pattern: str, context: int = 1) -> str:
        full = self._outputs.get(output_id)
        if full is None:
            return f"ERROR: unknown output_id {output_id!r}; stored: {', '.join(self._outputs) or 'none'}"
        try:
            rx = re.compile(pattern, re.IGNORECASE)
        except re.error as exc:
            return f"ERROR: bad regex: {exc}"
        lines = full.splitlines()
        ctx = max(0, min(int(context or 0), 5))
        hits = [i for i, line in enumerate(lines) if rx.search(line)]
        if not hits:
            return f"no matches in {output_id} ({len(lines)} lines)"
        chunks, shown = [], set()
        for i in hits[:40]:
            block = [j for j in range(max(0, i - ctx), min(len(lines), i + ctx + 1)) if j not in shown]
            shown.update(block)
            chunks.append("\n".join(f"{j + 1}: {lines[j][:400]}" for j in block))
        more = f"\n…{len(hits) - 40} more matches" if len(hits) > 40 else ""
        return f"{len(hits)} matches:\n" + "\n---\n".join(chunks) + more

    def _resolve_refs(self, value: Any) -> Any:
        if isinstance(value, str) and value in self.result.images:
            return self.result.images[value]
        if isinstance(value, dict):
            return {k: self._resolve_refs(v) for k, v in value.items()}
        if isinstance(value, list):
            return [self._resolve_refs(v) for v in value]
        return value

    async def call_mcp(self, mcp_name: str, args: dict[str, Any]) -> str:
        tool = self.tool_defs.get(mcp_name)
        schema = getattr(tool, "inputSchema", None) or {}
        props = schema.get("properties") if isinstance(schema, dict) else None
        args = dict(self._resolve_refs(args or {}))
        if isinstance(props, dict) and "agent_id" in props:
            args.setdefault("agent_id", self.agent_id)
        key = f"{mcp_name}:{json.dumps(args, sort_keys=True, default=str)}"
        if key in self._call_cache:
            return self._call_cache[key] + "\n(note: identical call already made; same result)"
        timeout = max(2.0, min(self.tool_timeout_s, self.time_left() - 2))
        try:
            raw = await asyncio.wait_for(self.session.call_tool(mcp_name, args), timeout=timeout)
            text = self._render_result(raw)
        except asyncio.TimeoutError:
            text = f"ERROR: {mcp_name} timed out after {timeout:.0f}s"
        except Exception as exc:
            text = f"ERROR: {type(exc).__name__}: {str(exc)[:500]}"
        if mcp_name not in self.result.tools_used:
            self.result.tools_used.append(mcp_name)
        notes = decoders.annotate(text) if not text.startswith("ERROR") else []
        if notes:
            text += "\n[auto-decoded] " + "\n[auto-decoded] ".join(notes)
        unlisted = self._unlisted_tool_names(text)
        if unlisted:
            text += (
                "\n[note] These tool names are NOT in the listed tools but may be callable — use call_tool_raw: "
                + ", ".join(unlisted[:20])
            )
        if not text.startswith("ERROR"):
            self._call_cache[key] = text  # failures may be transient: allow retries
        else:
            self._call_counts[key] = self._call_counts.get(key, 0) + 1
            if self._call_counts[key] >= 2:
                text += (
                    f"\n(note: this exact call has now failed {self._call_counts[key]} times. Change the arguments as "
                    "the error says, try call_tool_raw, or try a different tool.)"
                )
        return text

    def _unlisted_tool_names(self, text: str) -> list[str]:
        """Tool names a result enumerates (e.g. a tools/capabilities listing) that list_tools hid."""
        try:
            data = json.loads(text.split("\n[auto-decoded]")[0])
        except (ValueError, TypeError):
            return []
        names: list[str] = []

        def walk(node: Any, key: str = "") -> None:
            if isinstance(node, dict):
                for k, v in node.items():
                    walk(v, str(k))
            elif isinstance(node, list):
                for item in node:
                    if isinstance(item, str) and "tool" in key.lower():
                        names.append(item)
                    elif isinstance(item, dict) and "tool" in key.lower() and isinstance(item.get("name"), str):
                        names.append(item["name"])
                    else:
                        walk(item, key)

        walk(data)
        known = set(self.tool_defs)
        return [n for n in dict.fromkeys(names) if n not in known and re.fullmatch(r"[\w.\-/]{2,80}", n)]

    async def _read_resource(self, uri: str) -> str:
        try:
            res = await asyncio.wait_for(self.session.read_resource(uri), timeout=10)
        except Exception as exc:
            return f"ERROR: {type(exc).__name__}: {str(exc)[:300]}"
        parts = []
        for item in getattr(res, "contents", None) or []:
            if getattr(item, "text", None) is not None:
                parts.append(str(item.text))
            elif getattr(item, "blob", None):
                mime = getattr(item, "mimeType", "") or "application/octet-stream"
                if mime.startswith("image/"):
                    parts.append(f"[image: {self._store_image(f'data:{mime};base64,{item.blob}')}]")
                else:
                    parts.append(f"[binary {mime}, base64]: {str(item.blob)[:3000]}")
        text = self._shrink("\n".join(parts) or "(empty resource)")
        notes = decoders.annotate(text)
        return text + ("\n[auto-decoded] " + "\n[auto-decoded] ".join(notes) if notes else "")

    async def _get_prompt(self, name: str, arguments: dict[str, Any] | None) -> str:
        try:
            res = await asyncio.wait_for(
                self.session.get_prompt(name, {k: str(v) for k, v in (arguments or {}).items()}), timeout=10
            )
        except Exception as exc:
            return f"ERROR: {type(exc).__name__}: {str(exc)[:300]}"
        parts = [str(getattr(res, "description", "") or "")]
        for msg in getattr(res, "messages", None) or []:
            content = getattr(msg, "content", None)
            parts.append(f"{getattr(msg, 'role', '')}: {getattr(content, 'text', content)}")
        return self._shrink("\n".join(p for p in parts if p))

    async def execute(self, fn: str, args: dict[str, Any]) -> str:
        if fn == "decode_data":
            return decoders.decode(args.get("text", ""), args.get("method", "auto"), args.get("key", ""))
        if fn == "run_python":
            return await asyncio.to_thread(run_python, args.get("code", ""))
        if fn == "read_resource":
            return await self._read_resource(str(args.get("uri", "")))
        if fn == "grep_output":
            return self.grep_output(str(args.get("output_id", "")), str(args.get("pattern", "")), args.get("context", 1))
        if fn == "call_tool_raw":
            name = str(args.get("name", "")).strip()
            raw_args = args.get("arguments") if isinstance(args.get("arguments"), dict) else {}
            if not name or _BLOCKED_TOOL.search(name) or name in self.exclude_tools:
                return f"ERROR: {name!r} cannot be called here"
            return await self.call_mcp(name, raw_args)
        if fn == "get_prompt":
            return await self._get_prompt(str(args.get("name", "")), args.get("arguments"))
        mcp_name = self.fn_to_mcp.get(fn) or (fn if fn in self.tool_defs and not _BLOCKED_TOOL.search(fn) else "")
        if not mcp_name:
            return f"ERROR: no tool named {fn!r}. Available: {', '.join(list(self.fn_to_mcp)[:40])}"
        return await self.call_mcp(mcp_name, args)

    # ---------- recon ----------
    async def recon(self) -> str:
        """Call cheap read-only tools and read small resources before the model starts."""
        probes = [
            name
            for name in self.fn_to_mcp.values()
            if name not in self.skip_tools
            and _PROBE_TOOL.search(name)
            and not _required_args(getattr(self.tool_defs[name], "inputSchema", None))
        ][:6]
        coros = [self.call_mcp(name, {}) for name in probes]
        res_uris = [str(getattr(r, "uri", "")) for r in self.resources[:6]]
        coros += [self._read_resource(uri) for uri in res_uris]
        argless_prompts = [
            str(getattr(p, "name", ""))
            for p in self.prompts[:4]
            if not any(getattr(a, "required", False) for a in (getattr(p, "arguments", None) or []))
        ]
        coros += [self._get_prompt(name, {}) for name in argless_prompts]
        if not coros:
            return ""
        outputs = await asyncio.gather(*coros, return_exceptions=True)
        labels = [f"tool {n}()" for n in probes] + [f"resource {u}" for u in res_uris] + [f"prompt {n}" for n in argless_prompts]
        lines = []
        for label, out in zip(labels, outputs):
            text = out if isinstance(out, str) else f"ERROR: {out}"
            lines.append(f"## {label}\n{text[:2500]}")
        return "\n\n".join(lines)

    # ---------- LLM ----------
    def _tool_specs(self) -> list[dict[str, Any]]:
        specs = []
        for fn, mcp_name in list(self.fn_to_mcp.items())[:_MAX_FUNCTIONS - len(LOCAL_TOOLS)]:
            tool = self.tool_defs[mcp_name]
            desc = str(getattr(tool, "description", "") or "")[:1000] or f"MCP tool {mcp_name}"
            if fn != mcp_name:
                desc = f"[MCP tool {mcp_name}] {desc}"
            specs.append({
                "type": "function",
                "function": {"name": fn, "description": desc, "parameters": _clean_schema(getattr(tool, "inputSchema", None))},
            })
        return specs + LOCAL_TOOLS

    def _count_usage(self, response: Any) -> None:
        usage = getattr(response, "usage", None)
        for key in ("prompt_tokens", "completion_tokens", "total_tokens"):
            self.result.usage[key] += int(getattr(usage, key, 0) or 0) if usage else 0

    async def _chat(self, messages: list[dict[str, Any]], *, tools: bool) -> Any:
        last_exc: Exception | None = None
        for model in list(self.models):
            budget = self.time_left() - 3
            if budget < 3:
                break
            kwargs: dict[str, Any] = {"model": model, "messages": messages, "max_tokens": self.max_tokens}
            if self.temperature is not None:
                kwargs["temperature"] = self.temperature
            if tools:
                kwargs["tools"] = self._tool_specs()
                kwargs["tool_choice"] = "auto"
            try:
                response = await asyncio.wait_for(
                    asyncio.to_thread(lambda: self.llm.chat.completions.create(**kwargs, timeout=min(90.0, budget))),
                    timeout=min(95.0, budget + 1),
                )
                self.result.model = model
                self._count_usage(response)
                return response
            except Exception as exc:  # model down, no tool support, timeout: next model
                last_exc = exc
                self._log(f"   explorer: {model} failed ({type(exc).__name__}: {str(exc)[:160]}); trying next model")
                self.models.remove(model)
                self.models.append(model)  # keep as a last resort
                if len(self.models) == 1:
                    break
        raise RuntimeError(f"all explorer models failed: {last_exc}")

    def _trim_history(self, messages: list[dict[str, Any]]) -> None:
        total = sum(len(str(m.get("content") or "")) for m in messages)
        for msg in messages[2:]:
            if total <= _HISTORY_CHARS:
                break
            if msg.get("role") == "tool" and len(str(msg.get("content") or "")) > 600:
                old = str(msg["content"])
                msg["content"] = old[:500] + "\n…[older result trimmed]"
                total -= len(old) - len(msg["content"])

    # ---------- main loop ----------
    async def run(self, task: str, *, extra_context: str = "", answer_hint: str = "") -> ExplorerResult:
        started = time.monotonic()
        if not self.tool_defs:
            await self.discover()
        recon = await self.recon()
        inventory = self.inventory_text()
        self._thought(f"Explorer: {len(self.fn_to_mcp)} tools, {len(self.resources)} resources, {len(self.prompts)} prompts discovered")
        user = [f"CHALLENGE:\n{task.strip()}"]
        if extra_context.strip():
            user.append(f"CONTEXT ALREADY GATHERED:\n{extra_context.strip()}")
        user.append(f"SERVER INVENTORY:\n{inventory}")
        if recon:
            user.append(f"RECON (already called for you):\n{recon}")
        user.append(
            f"Time budget: about {max(5, int(self.time_left()))}s and at most {self.max_steps} turns. "
            + (answer_hint or "Finish with final_answer.")
        )
        messages: list[dict[str, Any]] = [
            {"role": "system", "content": self.system_prompt},
            {"role": "user", "content": "\n\n".join(user)},
        ]
        self.result.transcript.append({"role": "user", "content": messages[1]["content"]})
        nudged = warned = False
        repeats, last_signature = 0, ""
        for step in range(1, self.max_steps + 1):
            if self.time_left() < 8:
                self.result.timed_out = True
                break
            self.result.steps = step
            if not warned and (step == self.max_steps - 1 or self.time_left() < 20):
                warned = True
                messages.append({"role": "user", "content": "Almost out of time/turns: call final_answer now with your best answer."})
            try:
                response = await self._chat(messages, tools=True)
            except Exception as exc:
                self._log(f"   explorer: LLM unavailable ({exc})")
                break
            msg = response.choices[0].message
            calls = list(getattr(msg, "tool_calls", None) or [])
            content = str(getattr(msg, "content", "") or "")
            if not calls:
                calls = _textual_tool_calls(content, step)
            assistant: dict[str, Any] = {"role": "assistant", "content": content or None}
            if calls:
                assistant["tool_calls"] = [
                    {"id": c.id, "type": "function", "function": {"name": c.function.name, "arguments": c.function.arguments or "{}"}}
                    for c in calls
                ]
            messages.append(assistant)
            self.result.transcript.append({"step": step, "content": content[:2000], "calls": [
                {"name": c.function.name, "args": (c.function.arguments or "")[:1000]} for c in calls
            ]})
            if not calls:
                answer = extract_answer(content)
                if answer:
                    self.result.answer, self.result.reason = answer, "answered in text"
                    break
                if nudged:
                    break
                nudged = True
                messages.append({"role": "user", "content": "Continue: call tools to make progress, or call final_answer."})
                continue

            async def _run(call) -> tuple[Any, str]:
                try:
                    args = json.loads(call.function.arguments or "{}")
                    if not isinstance(args, dict):
                        args = {"value": args}
                except json.JSONDecodeError as exc:
                    return call, f"ERROR: arguments were not valid JSON ({exc}); resend."
                if call.function.name == FINAL_ANSWER:
                    return call, "__final__"
                return call, await self.execute(call.function.name, args)

            outcomes = await asyncio.gather(*(_run(c) for c in calls))
            # A model repeating itself is stuck: hand the episode to the next one.
            signature = json.dumps(sorted((c.function.name, c.function.arguments or "") for c in calls))
            repeats = repeats + 1 if signature == last_signature else 0
            last_signature = signature
            for call, output in outcomes:
                if output == "__final__":
                    try:
                        args = json.loads(call.function.arguments or "{}")
                    except json.JSONDecodeError:
                        args = {}
                    answer = str(args.get("answer", "") if isinstance(args, dict) else "").strip()
                    if answer:
                        self.result.answer = answer
                        self.result.reason = str(args.get("reason", ""))[:300]
                    output = "recorded" if answer else "ERROR: empty answer"
                else:
                    self._thought(f"🔧 {call.function.name}: {output[:140]}")
                messages.append({"role": "tool", "tool_call_id": call.id, "content": output})
                self.result.transcript.append({"tool": call.function.name, "output": output[:3000]})
            if self.result.answer and not _usable_answer(self.result.answer):
                self.result.answer = ""
                messages.append({"role": "user", "content": "That final_answer was not a usable answer. Give the actual answer value."})
            if self.result.answer:
                break
            if repeats >= 2 and len(self.models) > 1:
                stuck = self.models.pop(0)
                self.models.append(stuck)
                repeats = 0
                self._log(f"   explorer: {stuck} is repeating itself; switching to {self.models[0]}")
                self._thought(f"Switching model to {self.models[0]} (previous one was stuck)")
                messages.append({"role": "user", "content": "You are repeating the same calls. Step back, re-read the errors and outputs, and try a different approach."})
            # Hidden tools may have been unlocked by those calls.
            if any(self.fn_to_mcp.get(c.function.name) for c in calls):
                new = self._register_tools(await self._list_tools())
                if new:
                    note = "NEW TOOLS appeared: " + "; ".join(
                        f"{n}{_schema_summary(getattr(self.tool_defs[n], 'inputSchema', None))}: "
                        f"{str(getattr(self.tool_defs[n], 'description', '') or '')[:300]}" for n in new
                    )
                    self._thought(f"Discovered new tools: {', '.join(new)}")
                    messages.append({"role": "user", "content": note})
                    self.result.transcript.append({"note": note})
            self._trim_history(messages)

        if not self.result.answer and self.time_left() > 4:
            messages.append({"role": "user", "content": "Stop exploring. Reply with exactly one line: ANSWER: <your best final answer>"})
            try:
                response = await self._chat(messages + [], tools=False)
                text = str(response.choices[0].message.content or "")
                candidate = extract_answer(text) or (text.strip().splitlines()[-1].strip() if text.strip() else "")
                self.result.answer = candidate if _usable_answer(candidate) else ""
                self.result.reason = "forced final"
            except Exception as exc:
                self._log(f"   explorer: final answer call failed ({exc})")
        if not _usable_answer(self.result.answer):
            self.result.answer = ""
        if self.result.answer:
            self._draft(self.result.answer)
        self.result.elapsed_ms = int((time.monotonic() - started) * 1000)
        self._log(f"   explorer: {self.result.steps} steps, {time.monotonic() - started:.1f}s, tools used: {', '.join(self.result.tools_used) or '-'}")
        return self.result


def save_transcript(agent_id: str, result: ExplorerResult, root: Path) -> str:
    """Write the explorer transcript under outputs/ (best effort)."""
    try:
        path = transcript_path(agent_id, root)
        path.parent.mkdir(parents=True, exist_ok=True)
        payload = {
            "answer": result.answer,
            "reason": result.reason,
            "model": result.model,
            "steps": result.steps,
            "tools_used": result.tools_used,
            "usage": result.usage,
            "timed_out": result.timed_out,
            "transcript": result.transcript,
        }
        path.write_text(json.dumps(payload, indent=2, ensure_ascii=False, default=str))
        return str(path)
    except Exception as exc:
        return f"(transcript not saved: {exc})"


# Tools the stock Practice flows already handle. Anything else on the server
# is unexplored territory, so its presence routes a run to the explorer.
KNOWN_ARENA_TOOLS = frozenset({
    "arena.get_challenge", "arena.clues.list", "arena.clues.get", "arena.time_remaining", "arena.tools.list",
    "arena.image.get_challenge", "arena.image.broadcast_thought", "arena.image.submit_edit",
    "image_edit", "image_generate", "image_analyze",
})
_EXPLORE_WORDS = re.compile(
    r"\b(hidden|discover|explore|decrypt|encrypted|decode|cipher|ciphertext|encoded|vault|unlock|"
    r"server|tools?|mcp|sealed|secret|password|passphrase|key material)\b",
    re.IGNORECASE,
)


def route_reason(tool_names: list[str], challenge_text: str, *, keywords: bool = True) -> str:
    """Why this run needs the explorer ("" = the fast Practice path is enough).

    ``AGENT_EXPLORER=1`` forces the explorer and ``AGENT_EXPLORER=0`` disables it.
    """
    forced = os.getenv("AGENT_EXPLORER", "").strip().lower()
    if forced in {"1", "true", "yes", "always"}:
        return "forced by AGENT_EXPLORER"
    if forced in {"0", "false", "no", "never"}:
        return ""
    unknown = [t for t in tool_names if t not in KNOWN_ARENA_TOOLS]
    if unknown:
        return f"{len(unknown)} unfamiliar tools ({', '.join(unknown[:5])}{'…' if len(unknown) > 5 else ''})"
    if decoders.looks_encoded(challenge_text):
        return "challenge carries encoded data"
    match = _EXPLORE_WORDS.search(challenge_text or "") if keywords else None
    if match:
        return f"challenge mentions {match.group(0)!r}"
    return ""


def transcript_path(agent_id: str, root: Path) -> Path:
    override = os.getenv("EXPLORER_TRANSCRIPT", "").strip()
    return Path(override) if override else root / "outputs" / f"{agent_id}-explorer.json"
