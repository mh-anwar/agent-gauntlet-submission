#!/usr/bin/env python3
"""Simple Agent Gauntlet competitor agent.

This is a minimal example showing how to connect to Agent Gauntlet from any Python code.
It uses:
- HTTP client for Agent Gauntlet coordination (REST API)
- MCP client for challenge tools
- OpenAI SDK for LLM calls via the proxy

Usage:
    cd examples/python_simple
    python agent.py

This example loads `.env` from the repository root automatically.
"""

import asyncio
import json
import os
import re
import sys
import time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from urllib.error import HTTPError
from urllib.parse import quote
from urllib.request import Request, urlopen

from dotenv import load_dotenv

REPO_ROOT = Path(__file__).resolve().parent.parent.parent
if str(REPO_ROOT) not in sys.path: 
    sys.path.insert(0, str(REPO_ROOT))

load_dotenv(REPO_ROOT / ".env")

from arena_clients.config import agent_id_problem
from arena_clients import (
    ArenaAPIError,
    ArenaConnectionError,
    build_image_tool_arguments,
    HttpArenaClient,
    McpArenaClient,
    McpArenaError,
    ensure_connected,
    get_api_base,
    get_arena_api_key,
    get_mcp_url,
    get_proxy_host,
    monitor_session,
)
from arena_clients.explorer import (
    Explorer,
    route_reason,
    save_transcript,
)
from arena_clients.mcp_client import ChallengeInfo
from arena_clients.display import (
    ReasoningTicker,
    challenge_record,
    print_challenge,
    save_run_record,
    summary_lines,
)
from arena_clients.outputs import missing_tools_note, save_submitted_image, submission_summary_lines
from arena_clients.proxy_headers import build_proxy_headers, resolve_usage_scope
from base_strategy import ChallengeContext
from model_selector import (
    ModelSelectionError,
    fetch_available_models,
    require_explicit_model,
)
from my_strategy import MyStrategy

# Use OpenAI SDK for LLM calls through the proxy.
try:
    from openai import OpenAI

    HAS_OPENAI = True
except ImportError:
    HAS_OPENAI = False


BLANK_PNG_DATA_URI = (
    "data:image/png;base64,"
    "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO7/"
    "S7sAAAAASUVORK5CYII="
)


def _plan_image_tool_sequence(
    strategy: MyStrategy,
    ctx: ChallengeContext,
    available_tools: list[str],
) -> list[str]:
    """Expand an analysis-first choice into a usable image-output plan."""
    selected_tool = strategy.plan_image_tool(ctx, available_tools)
    if not selected_tool:
        return []
    sequence = [selected_tool]
    if selected_tool != "image_analyze":
        return sequence
    if ctx.image_url and "image_edit" in available_tools:
        sequence.append("image_edit")
    elif "image_generate" in available_tools:
        sequence.append("image_generate")
    return sequence


def extract_answer(raw_response: str) -> str:
    """Extract the answer line from the LLM response."""
    cleaned = re.sub(r"<think>.*?(?:</think>|$)", "", raw_response, flags=re.DOTALL).strip()

    # Accept either "ANSWER:" or "Final answer:" on its own line.
    for match in re.finditer(
        r"^[ \t]*(?:answer|final answer)[ \t]*:[ \t]*(.*?)[ \t]*$",
        cleaned,
        flags=re.IGNORECASE | re.MULTILINE,
    ):
        # A JSON answer may span lines after the ANSWER: marker; keep it whole.
        tail = cleaned[match.start(1):].lstrip()
        if tail[:1] in ("{", "["):
            try:
                value, _ = json.JSONDecoder().raw_decode(tail)
                return json.dumps(value, ensure_ascii=False)
            except ValueError:
                pass
        answer = match.group(1).strip().strip("`\"'")
        if answer:
            return answer

    return ""


def _challenge_text_blob(
    challenge_type: str,
    description: str,
    rules: str,
    extra_context: str = "",
) -> str:
    return " ".join(
        [challenge_type or "", description or "", rules or "", extra_context or ""]
    ).lower()


def _required_runtime_tools(
    available_tool_names: list[str],
    *,
    challenge_type: str,
    description: str,
    rules: str,
    extra_context: str = "",
) -> list[str]:
    blob = _challenge_text_blob(challenge_type, description, rules, extra_context)
    required: list[str] = []
    for tool_name in available_tool_names:
        normalized = str(tool_name or "").strip()
        if not normalized:
            continue
        if normalized.lower() in blob:
            required.append(normalized)
    if challenge_type.strip().lower() in {"web-search", "market-research"}:
        for tool_name in available_tool_names:
            normalized = str(tool_name or "").strip()
            if "search" in normalized.lower() and normalized not in required:
                required.append(normalized)
    return required


def _best_search_query(description: str, rules: str, clues: list[str] | None) -> str:
    text = (description or "").strip()
    if text:
        return text
    if clues:
        for clue in clues:
            if isinstance(clue, str) and clue.strip():
                return clue.strip()
    return (rules or "").strip()


def _query_candidates(
    description: str,
    rules: str,
    clues: list[str] | None,
    extra_context: str = "",
) -> list[str]:
    candidates: list[str] = []
    primary = _best_search_query(description, rules, clues)
    if primary:
        candidates.append(primary)
    for clue in clues or []:
        if isinstance(clue, str) and clue.strip():
            candidates.append(clue.strip())
    if isinstance(rules, str) and rules.strip():
        split_parts = re.split(r"[.;\n]+", rules)
        for part in split_parts:
            part = part.strip()
            if 8 <= len(part) <= 220:
                candidates.append(part)
    for text in [description, rules, extra_context, *(clues or [])]:
        if not isinstance(text, str):
            continue
        for url in re.findall(r"https?://[^\s)>\"]+", text):
            cleaned = url.strip().rstrip(".,);")
            if cleaned:
                candidates.append(cleaned)
    deduped: list[str] = []
    seen: set[str] = set()
    for item in candidates:
        key = item.lower()
        if key in seen:
            continue
        seen.add(key)
        deduped.append(item)
    return deduped[:5]


def _tool_result_text(result: object) -> str:
    if result is None:
        return ""
    if isinstance(result, str):
        return result.strip()
    if isinstance(result, (int, float, bool)):
        return str(result)
    if isinstance(result, list):
        parts = [_tool_result_text(item) for item in result]
        return "\n".join(part for part in parts if part).strip()
    if isinstance(result, dict):
        cleaned: dict[str, object] = {}
        for key, value in result.items():
            key_lower = str(key).lower()
            if "image" in key_lower and isinstance(value, str) and len(value) > 256:
                continue
            cleaned[str(key)] = value
        try:
            return json.dumps(cleaned, ensure_ascii=False)
        except Exception:
            return str(cleaned)
    return str(result)


def _is_invalid_answer_candidate(value: str) -> bool:
    text = str(value or "").strip()
    if not text:
        return True
    lowered = text.lower()
    if lowered.startswith(("<toolcall", "toolcall", "<think", "reasoning:", "analysis:", "action:")):
        return True
    blocked_tokens = ("<toolcall", "</toolcall", '"tool_calls"', "function_call")
    return any(token in lowered for token in blocked_tokens)


def _derive_answer_from_evidence(
    *,
    llm_client,
    model_name: str,
    challenge_description: str,
    challenge_rules: str,
    evidence_lines: list[str],
    max_tokens: int = 8192,
) -> str:
    if not evidence_lines:
        return ""
    evidence_block = "\n".join(f"- {line}" for line in evidence_lines if line.strip())
    if not evidence_block:
        return ""
    try:
        response = llm_client.chat.completions.create(
            model=model_name,
            messages=[
                {
                    "role": "system",
                    "content": (
                        "Use the provided tool evidence to answer the challenge. "
                        "Return only one final answer line that follows the challenge rules."
                    ),
                },
                {
                    "role": "user",
                    "content": (
                        f"Question: {challenge_description}\n"
                        f"Rules: {challenge_rules}\n\n"
                        f"Tool evidence:\n{evidence_block}\n\n"
                        "Return only the final answer line."
                    ),
                },
            ],
            max_tokens=max_tokens,
            temperature=0.0,
        )
    except Exception:
        return ""
    raw = (response.choices[0].message.content or "").strip()
    answer = extract_answer(raw)
    if answer:
        return answer
    first_line = raw.splitlines()[0].strip().strip("`\"'") if raw.strip() else ""
    return "" if _is_invalid_answer_candidate(first_line) else first_line


def _effort_kwargs(strategy, model_name: str) -> dict:
    """reasoning_effort for models the strategy has measured it on, else nothing."""
    effort = getattr(strategy, "reasoning_effort", lambda _model: None)(model_name)
    return {"reasoning_effort": effort} if effort else {}


async def _fetch_clues(mcp_client: McpArenaClient, agent_id: str, tools: list) -> tuple[list[str], set[str]]:
    """Clue texts plus the clue tools actually called (for required-tool bookkeeping)."""
    called: set[str] = set()
    try:
        if "arena.clues.list" not in tools:
            return [], called
        clue_ids = await mcp_client.list_clues(agent_id)
        called.add("arena.clues.list")
        fetched = await asyncio.gather(*(mcp_client.get_clue(clue_id, agent_id) for clue_id in clue_ids))
        if clue_ids:
            called.add("arena.clues.get")
        return [clue.text for clue in fetched], called
    except Exception as exc:
        print(f"   ⚠️  Clue tools failed ({type(exc).__name__}); continuing without clues.")
        return [], called


async def _enforce_required_tool_calls(
    *,
    mcp_client: McpArenaClient,
    agent_id: str,
    challenge_type: str,
    description: str,
    rules: str,
    clues: list[str] | None,
    available_tool_names: list[str],
    http_client: HttpArenaClient,
    extra_context: str = "",
    already_called: set[str] | frozenset[str] = frozenset(),
) -> list[str]:
    # Tools the main flow already called count as covered; calling them again
    # cost ~1.2s of scored time on every Practice puzzle.
    required_runtime_tools = [
        name
        for name in _required_runtime_tools(
            available_tool_names,
            challenge_type=challenge_type,
            description=description,
            rules=rules,
            extra_context=extra_context,
        )
        if name not in already_called
    ]
    if not required_runtime_tools:
        return []

    evidence_lines: list[str] = []
    queries = _query_candidates(description, rules, clues, extra_context)
    if not queries:
        queries = [""]
    for tool_name in required_runtime_tools:
        is_search_like = "search" in tool_name.lower()
        target_calls = min(len(queries), 3) if is_search_like else 1
        calls_made = 0
        for query in queries[:target_calls]:
            payload_variants = [
                {"agent_id": agent_id, "query": query},
                {"query": query},
                {"agent_id": agent_id, "search_query": query},
                {"search_query": query},
                {"agent_id": agent_id, "text": query},
                {"text": query},
                {"agent_id": agent_id, "url": query},
                {"url": query},
                {"agent_id": agent_id, "video_url": query},
                {"video_url": query},
                {"agent_id": agent_id},
                {},
            ]
            for payload in payload_variants:
                try:
                    result = await mcp_client.call_tool(tool_name, payload)
                    rendered = _tool_result_text(result)
                    if rendered:
                        evidence_lines.append(f"{tool_name}: {rendered[:2000]}")
                    calls_made += 1
                    break
                except Exception:
                    continue
        status_note = (
            f"Required tool coverage: {tool_name} ({calls_made}/{target_calls})"
            if target_calls > 1
            else f"Required tool called: {tool_name}"
            if calls_made
            else f"Could not call required tool: {tool_name}"
        )
        try:
            http_client.broadcast_thought(agent_id, status_note)
        except Exception:
            pass
    return evidence_lines


def _build_context(
    *,
    challenge_type: str,
    description: str,
    rules: str,
    clues: list[str] | None = None,
    max_time_s: int = 0,
    available_models: list[str] | None = None,
    time_remaining_s: float = 0.0,
    tokens_used: int = 0,
    image_url: str | None = None,
) -> ChallengeContext:
    return ChallengeContext(
        challenge_type=challenge_type,
        difficulty="unknown",
        challenge_text=description,
        description=description,
        rules=rules,
        clues=list(clues or []),
        time_remaining_s=time_remaining_s,
        max_time_s=max_time_s,
        available_models=list(available_models or []),
        tools_used=[],
        tokens_used=tokens_used,
        required_tools=[],
        image_url=image_url,
    )


def _coerce_nonnegative_int(value: object, default: int = 0) -> int:
    try:
        return max(0, int(value if value is not None else default))
    except (TypeError, ValueError):
        return default


def _fetch_proxy_usage(
    llm_host: str,
    api_key: str,
    agent_id: str,
    scope_id: str | None = None,
) -> dict[str, int] | None:
    """Best-effort fetch of proxy usage for one agent, scoped when possible."""
    if not llm_host or not api_key or not agent_id:
        return None
    encoded_agent_id = quote(agent_id, safe="")

    def _read_usage(url: str) -> dict[str, int] | None:
        request = Request(
            url,
            headers={"Authorization": f"Bearer {api_key}", "Accept": "application/json"},
            method="GET",
        )
        with urlopen(request, timeout=1.0) as response:
            payload = json.loads(response.read().decode("utf-8"))
        usage = payload.get("usage")
        if not isinstance(usage, dict):
            return None
        return {
            "prompt_tokens": _coerce_nonnegative_int(usage.get("prompt_tokens")),
            "completion_tokens": _coerce_nonnegative_int(usage.get("completion_tokens")),
            "total_tokens": _coerce_nonnegative_int(usage.get("total_tokens")),
        }

    if scope_id:
        encoded_scope_id = quote(scope_id, safe="")
        scoped_url = f"{llm_host.rstrip('/')}/usage/{encoded_scope_id}/{encoded_agent_id}"
        try:
            return _read_usage(scoped_url)
        except HTTPError as exc:
            if exc.code not in {400, 404}:
                raise

    aggregate_url = f"{llm_host.rstrip('/')}/usage/{encoded_agent_id}"
    return _read_usage(aggregate_url)


def _build_live_metrics(model_name: str, usage: dict[str, int] | None, elapsed_ms: int) -> dict[str, object]:
    usage = usage or {}
    prompt_tokens = _coerce_nonnegative_int(usage.get("prompt_tokens"))
    completion_tokens = _coerce_nonnegative_int(usage.get("completion_tokens"))
    total_tokens = _coerce_nonnegative_int(usage.get("total_tokens"))
    return {
        "model_name": str(model_name or "").strip(),
        "total_tokens": str(total_tokens),
        "prompt_tokens": str(prompt_tokens),
        "completion_tokens": str(completion_tokens),
        "total_time_ms": int(max(0, elapsed_ms)),
    }


# A retry with another model needs time to think and answer.
RETRY_MIN_REMAINING_S = 30.0


def _submit_with_retry(http_client, *args, attempts: int = 3, **kwargs):
    """Resend the exact same answer after a network or 5xx failure.

    The server returns the original receipt for an identical resubmit, so this
    is safe; a lost response (seen on Practice as a 30s read timeout) would
    otherwise crash the run without a recorded result.
    """
    for attempt in range(attempts):
        try:
            return http_client.submit(*args, **kwargs)
        except (ArenaConnectionError, ArenaAPIError) as exc:
            retryable = isinstance(exc, ArenaConnectionError) or getattr(exc, "status_code", 0) >= 500
            if not retryable or attempt == attempts - 1:
                raise
            print(f"   ⚠️  Submit failed ({type(exc).__name__}); resending the same answer.")


def _next_ranked_model(ranked_models: list[str], current: str) -> str:
    """The first ranked model after ``current``, or "" when there is none."""
    remaining = [model for model in ranked_models if model != current]
    if current in ranked_models:
        after = ranked_models[ranked_models.index(current) + 1 :]
        remaining = [model for model in after if model != current] or remaining
    return remaining[0] if remaining else ""


async def _retry_after_length_stop(result, *, ranked_models, remaining_s, solve_with):
    """Retry once with the next ranked model when the first ran out of tokens.

    ``result`` is solve_challenge's tuple. A reasoning model that spends its
    whole token budget thinking returns no answer with finish_reason
    "length"; asking it again would do the same, so another model gets one
    try while enough time remains. Token usage and time add up across both.
    """
    answer, _raw, model_name, usage, _ttft, total_time_ms = result
    if _is_invalid_answer_candidate(answer):
        answer = ""
    if answer or usage.get("finish_reason") != "length":
        return result
    tokens_spent = int(usage.get("completion_tokens", 0) or 0)
    print(f"   ⚠️  {model_name} used all {tokens_spent} tokens thinking and gave no answer.")
    retry_model = _next_ranked_model(ranked_models, model_name)
    left_s = await remaining_s()
    if not retry_model or left_s < RETRY_MIN_REMAINING_S:
        print(f"   Not retrying ({left_s:.0f}s left). Tune text_max_tokens or rank_models in my_strategy.py.")
        return result
    print(f"   Retrying with {retry_model}. Tune text_max_tokens or rank_models in my_strategy.py.")
    retried = await solve_with(retry_model)
    r_answer, r_raw, r_model, r_usage, r_ttft, r_time_ms = retried
    merged_usage = dict(r_usage)
    for key in ("prompt_tokens", "completion_tokens", "total_tokens"):
        merged_usage[key] = int(r_usage.get(key, 0) or 0) + int(usage.get(key, 0) or 0)
    return r_answer, r_raw, r_model, merged_usage, r_ttft, total_time_ms + r_time_ms


async def solve_challenge(
    challenge,
    clues: list[str],
    llm_client,
    model_name: str,
    strategy: MyStrategy,
    ctx: ChallengeContext,
    *,
    http_client=None,
    agent_id: str = "",
    broadcast_thought: bool = True,
    evidence_lines: list[str] | None = None,
    ticker: ReasoningTicker | None = None,
):
    """Solve the challenge using the selected LLM model.
    
    When http_client and agent_id are provided, streams reasoning to Agent Gauntlet in real time.
    
    Returns:
        tuple: (extracted_answer, raw_response, model_name, usage_dict, ttft_ms, total_time_ms)
    """
    
    _ = challenge
    _ = clues
    prompt = strategy.build_solver_prompt(ctx)
    if evidence_lines:
        # Retrieval-style challenges: the model must see what the tools returned.
        evidence_block = "\n".join(f"- {line}" for line in evidence_lines if line.strip())
        prompt = f"{prompt}\n\nTool evidence:\n{evidence_block}"
    prompt = (
        f"{prompt}\n\n"
        "Output guardrails:\n"
        "- Return only your final answer line.\n"
        "- Do not output tool-call markup, XML tags, or thinking traces."
    )
    system_msg = strategy.build_system_prompt(ctx)
    llm_params = strategy.get_llm_params(ctx)
    max_tokens = int(llm_params.get("max_tokens", 8192))
    temperature = float(llm_params.get("temperature", 0.0))
    
    # Track timing
    start_ms = time.time() * 1000
    ttft_ms = 0
    raw_content_parts = []
    # Kept apart so the answer comes from the final reply, as in the
    # non-streaming path; reasoning can hold draft "ANSWER:" lines.
    reply_parts: list[str] = []
    reasoning_parts: list[str] = []
    pending_broadcast = ""
    _BROADCAST_CHUNK = 80  # chars before sending a thought

    def _flush_broadcast(force: bool = False) -> None:
        nonlocal pending_broadcast
        if not http_client or not agent_id or not broadcast_thought:
            return
        if force or len(pending_broadcast) >= _BROADCAST_CHUNK or "\n" in pending_broadcast:
            chunk = pending_broadcast.strip()
            pending_broadcast = ""
            if chunk:
                try:
                    http_client.broadcast_thought(agent_id, chunk[:300])
                except Exception:
                    pass

    stream_enabled = os.getenv("LLM_STREAM", "1").lower() not in {"0", "false", "no"}
    usage = None
    finish_reason = ""
    if stream_enabled and http_client and agent_id:
        # Stream and broadcast in real time
        try:
            stream = llm_client.chat.completions.create(
                model=model_name,
                messages=[
                    {"role": "system", "content": system_msg},
                    {"role": "user", "content": prompt},
                ],
                max_tokens=max_tokens,
                temperature=temperature,
                stream=True,
            )
            header_sent = False
            for chunk in stream:
                if chunk.choices and getattr(chunk.choices[0], "finish_reason", None):
                    finish_reason = str(chunk.choices[0].finish_reason)
                if chunk.choices and chunk.choices[0].delta:
                    delta = chunk.choices[0].delta
                    content = delta.content or ""
                    reasoning = getattr(delta, "reasoning_content", None) or getattr(delta, "reasoning", None) or ""
                    text = reasoning or content
                    if ticker is not None:
                        ticker.feed(reasoning=reasoning, answer=content)
                    if reasoning:
                        reasoning_parts.append(reasoning)
                    if content:
                        reply_parts.append(content)
                    if text:
                        if not ttft_ms:
                            ttft_ms = int(time.time() * 1000 - start_ms)
                        raw_content_parts.append(text)
                        if broadcast_thought:
                            if not header_sent:
                                http_client.broadcast_thought(agent_id, "💭 LLM Reasoning:")
                                header_sent = True
                            pending_broadcast += text
                            _flush_broadcast()
                if hasattr(chunk, "usage") and chunk.usage:
                    usage = chunk.usage
            _flush_broadcast(force=True)
        except Exception as e:
            stream_enabled = False
            raw_content_parts = []
            if "stream" in str(e).lower() or "Stream" in str(e):
                pass  # Fall through to non-streaming
            else:
                raise

    if not stream_enabled or not raw_content_parts:
        # Non-streaming fallback
        response = llm_client.chat.completions.create(
            model=model_name,
            messages=[
                {"role": "system", "content": system_msg},
                {"role": "user", "content": prompt},
            ],
            max_tokens=max_tokens,
            temperature=temperature,
            **_effort_kwargs(strategy, model_name),
        )
        raw_content = response.choices[0].message.content or ""
        finish_reason = str(getattr(response.choices[0], "finish_reason", "") or "")
        usage = response.usage
        ttft_ms = ttft_ms or getattr(response, "ttft_ms", 0) or int((time.time() * 1000 - start_ms) * 0.1)
    else:
        reply = "".join(reply_parts)
        raw_content = reply if reply.strip() else "".join(reasoning_parts)

    total_time_ms = int(time.time() * 1000 - start_ms)
    answer = extract_answer(raw_content)
    if _is_invalid_answer_candidate(answer):
        answer = ""
    if not answer and evidence_lines:
        answer = _derive_answer_from_evidence(
            llm_client=llm_client,
            model_name=model_name,
            challenge_description=str(ctx.description or ""),
            challenge_rules=str(ctx.rules or ""),
            evidence_lines=list(evidence_lines or []),
            max_tokens=max_tokens,
        )
        if _is_invalid_answer_candidate(answer):
            answer = ""
    # A model that ran out of tokens while thinking would only do it again;
    # the caller retries with another model instead.
    if not answer and finish_reason != "length":
        strict_system_msg = (
            "Return only one line in exact format: ANSWER: <final answer>. "
            "No preamble, no tags, no explanation, no additional lines."
        )
        try:
            strict_response = llm_client.chat.completions.create(
                model=model_name,
                messages=[
                    {"role": "system", "content": strict_system_msg},
                    {"role": "user", "content": prompt},
                ],
                max_tokens=max_tokens,
                temperature=min(temperature, 0.0),
                stream=False,
                **_effort_kwargs(strategy, model_name),
            )
            raw_content = strict_response.choices[0].message.content or ""
            usage = strict_response.usage
            total_time_ms = int(time.time() * 1000 - start_ms)
            answer = extract_answer(raw_content)
        except Exception:
            pass
    if _is_invalid_answer_candidate(answer):
        answer = ""

    usage_dict = {
        "finish_reason": finish_reason,
        "prompt_tokens": getattr(usage, "prompt_tokens", 0) if usage else 0,
        "completion_tokens": getattr(usage, "completion_tokens", 0) if usage else 0,
        "total_tokens": getattr(usage, "total_tokens", 0) if usage else 0,
    }
    # Streams usually carry no usage; estimate from everything streamed,
    # reasoning included, not only the reply the answer was read from.
    streamed_text = "".join(raw_content_parts) or raw_content
    if not usage_dict["total_tokens"] and streamed_text:
        usage_dict["total_tokens"] = len(streamed_text.split()) * 2  # rough estimate
    ttft_ms = ttft_ms or int(total_time_ms * 0.1)

    return answer, raw_content, model_name, usage_dict, ttft_ms, total_time_ms


# Seconds kept back from the explorer for the fallback solve and the submit.
EXPLORER_RESERVE_S = 12.0
BRIEFLESS_DESCRIPTION = (
    "No challenge was provided by arena.get_challenge. The brief is somewhere on this "
    "server: find it (look for briefing/mission/challenge/task/readme/help tools, "
    "resources, or prompts), then solve it exactly as it asks."
)


def _rules_with_format(challenge) -> str:
    """Challenge rules plus its output_format field, which the solver never saw.

    With it, terra's answers matched the format's separators every time
    (4/4 per Practice puzzle) instead of mixing ", " and ",".
    """
    rules = str(getattr(challenge, "rules", "") or "")
    raw = getattr(challenge, "raw_data", None)
    fmt = str((raw or {}).get("output_format") or "").strip() if isinstance(raw, dict) else ""
    if fmt and fmt not in rules:
        rules = f"{rules}\nOutput format: {fmt}".strip()
    return rules


def _text_task(challenge) -> str:
    parts = [
        f"Type: {challenge.challenge_type or 'unknown'}",
        f"Description: {challenge.description or '(none)'}",
        f"Rules: {challenge.rules or '(none given)'}",
    ]
    extra = str(getattr(challenge, "extra_text", "") or "").strip()
    if extra:
        parts.append(f"Other challenge fields: {extra[:3000]}")
    return "\n".join(parts)


async def _remaining_or_default(mcp_client, agent_id: str, challenge) -> float:
    try:
        info = await mcp_client.time_remaining(agent_id)
        return float(info.get("time_remaining_s", 0.0)) or float(challenge.max_time_s or 120)
    except Exception:
        return float(getattr(challenge, "max_time_s", 0) or 120)


async def _briefless_challenge(mcp_client, agent_id: str) -> ChallengeInfo:
    """A stand-in challenge when the server gives no brief through arena.get_challenge."""
    max_time_s = 120
    try:
        info = await mcp_client.time_remaining(agent_id)
        max_time_s = int(float(info.get("max_time_s") or info.get("time_remaining_s") or 120))
    except Exception:
        pass
    return ChallengeInfo(
        challenge_type="black-box",
        challenge_id="",
        puzzle_id="",
        description=BRIEFLESS_DESCRIPTION,
        rules="Follow the rules stated in the brief you find.",
        max_time_s=max_time_s,
        clues=[],
        time_remaining_s=float(max_time_s),
        raw_data={},
    )


async def _run_explorer(
    *,
    mcp_client,
    llm_client,
    strategy,
    ranked_models: list[str],
    agent_id: str,
    task: str,
    extra_context: str,
    remaining_s: float,
    skip_tools: tuple[str, ...],
    post_async,
    http_client,
    answer_hint: str = "",
    exclude_tools: tuple[str, ...] = (),
    budget_fraction: float | None = None,
):
    """Run the MCP explorer; None if it could not run at all."""
    fraction = budget_fraction if budget_fraction is not None else float(getattr(strategy, "explorer_time_fraction", 0.75))
    budget = max(15.0, min(remaining_s * fraction, remaining_s - EXPLORER_RESERVE_S))
    thoughts_left = 30

    def thought(message: str) -> None:
        nonlocal thoughts_left
        if thoughts_left > 0:
            thoughts_left -= 1
            post_async(http_client.broadcast_thought, agent_id, message[:280])

    build_prompt = getattr(strategy, "build_explorer_prompt", None)
    explorer = Explorer(
        session=mcp_client._session,
        llm_client=llm_client,
        models=list(ranked_models),
        agent_id=agent_id,
        deadline=time.monotonic() + budget,
        max_steps=int(getattr(strategy, "explorer_max_steps", 16)),
        max_tokens=int(getattr(strategy, "explorer_max_tokens", 4096)),
        temperature=getattr(strategy, "explorer_temperature", 0.0),
        thought=thought,
        draft=lambda answer: post_async(http_client.save_draft, agent_id, answer, "explorer"),
        skip_tools=skip_tools,
        exclude_tools=exclude_tools,
        **({"system_prompt": build_prompt()} if callable(build_prompt) else {}),
    )
    try:
        result = await explorer.run(task, extra_context=extra_context, answer_hint=answer_hint)
    except Exception as exc:
        print(f"   ⚠️  Explorer failed ({type(exc).__name__}: {exc}); falling back.")
        return None
    print(f"   Explorer answer: {result.answer[:200] or '(none)'}  [{result.steps} steps, {result.elapsed_ms / 1000:.1f}s]")
    print(f"   Explorer transcript: {save_transcript(agent_id, result, REPO_ROOT)}")
    return result


async def main():
    """Main agent loop."""
    strategy = MyStrategy()
    agent_id = (
        os.getenv("AGENT_ID")
        or str(getattr(strategy, "agent_id", "")).strip()
        or "simple-agent"
    ).strip()
    agent_name = (
        os.getenv("AGENT_NAME")
        or str(getattr(strategy, "agent_name", "")).strip()
        or "Team Nova"
    ).strip()
    os.environ["AGENT_ID"] = agent_id
    # Practice is shared: a default id lets another team's run replace yours.
    id_problem = agent_id_problem(os.environ["AGENT_ID"])
    if id_problem:
        raise SystemExit(f"❌ {id_problem}")
    os.environ["AGENT_NAME"] = agent_name
    print(f"🤖 {agent_name} starting...")
    print(f"   Agent ID: {agent_id}")

    ensure_connected()

    # Initialize clients
    api_base = get_api_base()
    mcp_url = get_mcp_url()
    llm_host = get_proxy_host()
    api_key = get_arena_api_key()
    llm_api_key = api_key

    print(f"   API: {api_base}")
    print(f"   MCP: {mcp_url}")
    print(f"   LLM: {llm_host}")
    print()

    # HTTP client for Agent Gauntlet coordination
    http_client = HttpArenaClient(api_base=api_base, api_key=api_key)
    # Milestone thoughts/drafts are fire-and-forget: each blocking POST cost
    # ~0.35s of scored time. One worker keeps them in order.
    background = ThreadPoolExecutor(max_workers=1)

    posted: list = []

    def post_async(fn, *args) -> None:
        posted.append(background.submit(fn, *args))

    def wait_posted(timeout_s: float = 3.0) -> None:
        """Let queued thoughts land before submit (the broadcast penalty counts them)."""
        from concurrent.futures import wait as _wait
        _wait(list(posted), timeout=timeout_s)

    if not HAS_OPENAI:
        raise RuntimeError("Missing dependency: openai. Install with `pip install openai`.")
    
    # Step 1: Register with Agent Gauntlet
    print("📝 Registering with Agent Gauntlet...")
    session = http_client.register(agent_id, agent_name)
    print(f"   Session: {session.session_id}")
    print(f"   Status: {session.status}")
    session_monitor = monitor_session(http_client, agent_id).start()
    
    # Step 2: Get challenge from MCP
    print("\n🎯 Getting challenge...")
    async with McpArenaClient(mcp_url) as mcp_client:
        tools = await mcp_client.list_tools()
        tool_defs = await mcp_client.list_tool_defs()
        modality = McpArenaClient.detect_modality(tools, agent_id=agent_id)
        image_tool_proxy_args: dict[str, dict[str, str]] = {}
        usage_scope = http_client.fetch_usage_scope() or resolve_usage_scope()
        if usage_scope:
            os.environ["ARENA_USAGE_SCOPE"] = usage_scope

        live_prompt_tokens = 0
        live_completion_tokens = 0
        live_total_tokens = 0
        active_model_name = ""
        metrics_started_ms = 0.0
        reporter_stop = asyncio.Event()
        metrics_task: asyncio.Task | None = None

        def _elapsed_metrics_ms() -> int:
            if metrics_started_ms <= 0:
                return 0
            return int(max(0.0, time.time() * 1000 - metrics_started_ms))

        async def _refresh_live_usage() -> None:
            nonlocal live_prompt_tokens, live_completion_tokens, live_total_tokens
            try:
                usage = await asyncio.to_thread(
                    _fetch_proxy_usage,
                    llm_host,
                    llm_api_key,
                    agent_id,
                    usage_scope,
                )
            except Exception:
                usage = None
            if not isinstance(usage, dict):
                return
            live_prompt_tokens = _coerce_nonnegative_int(usage.get("prompt_tokens"))
            live_completion_tokens = _coerce_nonnegative_int(usage.get("completion_tokens"))
            live_total_tokens = _coerce_nonnegative_int(usage.get("total_tokens"))

        async def _push_live_status(status: str = "running") -> None:
            await _refresh_live_usage()
            try:
                await asyncio.to_thread(
                    http_client.update_status,
                    agent_id,
                    status,
                    _build_live_metrics(
                        active_model_name,
                        {
                            "prompt_tokens": live_prompt_tokens,
                            "completion_tokens": live_completion_tokens,
                            "total_tokens": live_total_tokens,
                        },
                        _elapsed_metrics_ms(),
                    ),
                )
            except Exception:
                return

        async def _runtime_metrics_reporter() -> None:
            while not reporter_stop.is_set():
                await _push_live_status("running")
                try:
                    await asyncio.wait_for(reporter_stop.wait(), timeout=1.0)
                except asyncio.TimeoutError:
                    continue

        async def _start_metrics_reporter(model_name: str) -> None:
            nonlocal active_model_name, metrics_started_ms, metrics_task
            active_model_name = str(model_name or "").strip()
            metrics_started_ms = time.time() * 1000
            reporter_stop.clear()
            # The reporter's first iteration pushes immediately; awaiting a
            # push here cost ~0.6s of scored time.
            metrics_task = asyncio.create_task(_runtime_metrics_reporter())

        async def _stop_metrics_reporter() -> None:
            # No final push: one more status round trip before submit cost
            # ~1.2s of scored time, and the submit carries the metrics.
            reporter_stop.set()
            if metrics_task is not None:
                try:
                    await asyncio.wait_for(metrics_task, timeout=2.0)
                except Exception:
                    if not metrics_task.done():
                        metrics_task.cancel()

        if modality == "image":
            models_task = asyncio.create_task(asyncio.to_thread(fetch_available_models, llm_host, llm_api_key))
            challenge = None
            while True:
                try:
                    challenge = await mcp_client.get_image_challenge(agent_id)
                    break
                except McpArenaError as e:
                    message = str(e).lower()
                    if "locked" in message or "waiting for organizer" in message:
                        print("   Lobby open; waiting for organizer to start battle...")
                        await asyncio.sleep(3.0)
                    else:
                        raise
            print_challenge(challenge)
            usage_scope = http_client.fetch_usage_scope() or resolve_usage_scope()
            if usage_scope:
                os.environ["ARENA_USAGE_SCOPE"] = usage_scope

            available_models = await models_task
            # A black-box image brief may be sealed or hidden behind other
            # tools; resolve it to a plain instruction before drawing.
            brief_text = "\n".join(
                str(part or "") for part in (challenge.description, challenge.prompt, challenge.reference_notes)
            )
            image_explore_why = route_reason([str(name) for name in tools], brief_text, keywords=False)
            if image_explore_why:
                print(f"\n🧭 Explorer resolving the image brief: {image_explore_why}")
                http_client.broadcast_thought(agent_id, f"Exploring the server for the image brief: {image_explore_why}")
                brief_ctx = _build_context(
                    challenge_type="text",
                    description=challenge.description,
                    rules=challenge.prompt,
                    max_time_s=challenge.max_time_s,
                    available_models=available_models,
                )
                text_models = [
                    m for m in strategy.rank_models(brief_ctx, available_models) if not m.endswith("-image")
                ] or available_models
                brief_llm = OpenAI(
                    base_url=llm_host,
                    api_key=llm_api_key,
                    default_headers=build_proxy_headers(agent_id, usage_scope),
                    max_retries=0,
                )
                explored_brief = await _run_explorer(
                    mcp_client=mcp_client,
                    llm_client=brief_llm,
                    strategy=strategy,
                    ranked_models=text_models,
                    agent_id=agent_id,
                    task=(
                        f"Image challenge ({challenge.challenge_type}).\nDescription: {challenge.description}\n"
                        f"Prompt as given: {challenge.prompt}\nReference notes: {challenge.reference_notes}"
                    ),
                    extra_context="",
                    remaining_s=float(challenge.time_remaining_s or challenge.max_time_s or 120),
                    skip_tools=("arena.image.get_challenge",),
                    exclude_tools=("image_generate", "image_edit", "arena.image.broadcast_thought"),
                    answer_hint=(
                        "Your job here is ONLY to work out the exact image instruction: find/decode any sealed or "
                        "hidden brief and gather every constraint. Do not create the image. Call final_answer with "
                        "the complete plain-language image instruction (subject, style, every constraint)."
                    ),
                    budget_fraction=0.45,
                    post_async=post_async,
                    http_client=http_client,
                )
                if explored_brief is not None and explored_brief.answer.strip():
                    challenge.prompt = explored_brief.answer.strip()
                    # The original description ("draw what the sealed brief says")
                    # would mislead the image model; the resolved brief replaces it.
                    challenge.description = challenge.prompt
                    challenge.reference_notes = ""
                    print(f"   Resolved image instruction: {challenge.prompt[:200]}")
            image_rules = "\n".join(
                part
                for part in (challenge.prompt, challenge.reference_notes)
                if isinstance(part, str) and part.strip()
            )
            image_prompt = (challenge.prompt or challenge.description or "").strip()
            image_ctx = _build_context(
                challenge_type=challenge.challenge_type,
                description=challenge.description,
                rules=image_rules,
                max_time_s=challenge.max_time_s,
                available_models=available_models,
                image_url=challenge.input_image_uri or None,
            )
            ranked_models = strategy.rank_models(image_ctx, available_models)
            model_name = strategy.pick_model("solve", ranked_models, image_ctx)
            model_name = require_explicit_model(
                model_name,
                available_models,
                source="python_simple agent",
            )
            image_tool_proxy_args = {
                tool_name: build_image_tool_arguments(
                    tool_defs,
                    tool_name,
                    selected_model=model_name,
                    llm_api_key=llm_api_key,
                    arena_api_key=api_key,
                )
                for tool_name in ("image_edit", "image_generate", "image_analyze")
            }
            print(f"   Selected model: {model_name}")
            post_async(http_client.broadcast_thought, agent_id, f"Selected planner model: {model_name}")
            await _start_metrics_reporter(model_name)

            start_ms = time.time() * 1000
            prompt_text = strategy.build_image_prompt(image_ctx).strip() or image_prompt
            image_tools = [
                tool_name
                for tool_name in ("image_edit", "image_generate", "image_analyze")
                if tool_name in tools
            ]
            image_tool_sequence = _plan_image_tool_sequence(
                strategy,
                image_ctx,
                image_tools,
            )
            selected_tool = image_tool_sequence[-1] if image_tool_sequence else ""
            tool_result: dict = {}
            mcp_session_dead = False

            async def _call_image_tool(name: str, arguments: dict) -> dict:
                nonlocal mcp_session_dead
                try:
                    result = await mcp_client.call_tool(name, arguments)
                    return result if isinstance(result, dict) else {}
                except asyncio.CancelledError:
                    raise
                except Exception as exc:
                    mcp_session_dead = True
                    print(f"   Image tool {name} failed ({type(exc).__name__}): {exc}")
                    return {}

            if (
                len(image_tool_sequence) > 1
                and image_tool_sequence[0] == "image_analyze"
                and challenge.input_image_uri
            ):
                print("   Using image_analyze before output tool")
                analysis_result = await _call_image_tool(
                    "image_analyze",
                    {
                        "image_uri": challenge.input_image_uri,
                        "question": prompt_text,
                        "agent_id": agent_id,
                        **image_tool_proxy_args.get("image_analyze", {}),
                    },
                )
                analysis_text = str(analysis_result.get("text") or "").strip()
                if analysis_text:
                    http_client.broadcast_thought(
                        agent_id,
                        f"Image analysis: {analysis_text[:180]}",
                    )
                    prompt_text = (
                        f"{prompt_text}\n\n"
                        "Source-image analysis to preserve while transforming: "
                        f"{analysis_text[:1000]}"
                    )
            if (
                selected_tool == "image_edit"
                and challenge.input_image_uri
                and "image_edit" in image_tools
            ):
                print("   Using image_edit tool")
                tool_result = await _call_image_tool(
                    "image_edit",
                    {
                        "image_uri": challenge.input_image_uri,
                        "prompt": prompt_text,
                        "agent_id": agent_id,
                        **image_tool_proxy_args.get("image_edit", {}),
                    },
                )
            elif selected_tool == "image_generate" and "image_generate" in image_tools:
                print("   Using image_generate tool")
                tool_result = await _call_image_tool(
                    "image_generate",
                    {
                        "prompt": prompt_text,
                        "agent_id": agent_id,
                        **image_tool_proxy_args.get("image_generate", {}),
                    },
                )
            elif (
                selected_tool == "image_analyze"
                and challenge.input_image_uri
                and "image_analyze" in image_tools
            ):
                print("   Using image_analyze tool (no image output tool available)")
                tool_result = await _call_image_tool(
                    "image_analyze",
                    {
                        "image_uri": challenge.input_image_uri,
                        "question": prompt_text,
                        "agent_id": agent_id,
                        **image_tool_proxy_args.get("image_analyze", {}),
                    },
                )
                analysis_text = str(tool_result.get("text") or "").strip()
                if analysis_text:
                    http_client.broadcast_thought(
                        agent_id,
                        f"Image analysis: {analysis_text[:180]}",
                    )
            elif challenge.input_image_uri and "image_edit" in image_tools:
                selected_tool = "image_edit"
                tool_result = await _call_image_tool(
                    "image_edit",
                    {
                        "image_uri": challenge.input_image_uri,
                        "prompt": prompt_text,
                        "agent_id": agent_id,
                        **image_tool_proxy_args.get("image_edit", {}),
                    },
                )
            elif "image_generate" in image_tools:
                selected_tool = "image_generate"
                tool_result = await _call_image_tool(
                    "image_generate",
                    {
                        "prompt": prompt_text,
                        "agent_id": agent_id,
                        **image_tool_proxy_args.get("image_generate", {}),
                    },
                )

            # The model returned no image (upstream error or text-only reply):
            # one try with the next ranked image model beats submitting the
            # unedited input or a blank PNG.
            fallback_model = _next_ranked_model(ranked_models, model_name)
            if (
                selected_tool in ("image_edit", "image_generate")
                and not str(tool_result.get("image_uri") or "").strip()
                and not mcp_session_dead
                and fallback_model
            ):
                print(f"   ⚠️  {model_name} returned no image ({tool_result.get('error') or 'empty'}); retrying with {fallback_model}")
                retry_args = {
                    "prompt": prompt_text,
                    "agent_id": agent_id,
                    **build_image_tool_arguments(
                        tool_defs,
                        selected_tool,
                        selected_model=fallback_model,
                        llm_api_key=llm_api_key,
                        arena_api_key=api_key,
                    ),
                }
                if selected_tool == "image_edit":
                    retry_args["image_uri"] = challenge.input_image_uri
                tool_result = await _call_image_tool(selected_tool, retry_args)
                model_name = fallback_model

            # No stock image tool on this server: let the explorer find
            # whatever produces images here and hand back its output.
            if not str(tool_result.get("image_uri") or "").strip() and not (
                {"image_edit", "image_generate"} & set(image_tools)
            ) and not mcp_session_dead:
                print("\n🧭 No stock image tool; exploring for one")
                produced = await _run_explorer(
                    mcp_client=mcp_client,
                    llm_client=OpenAI(
                        base_url=llm_host,
                        api_key=llm_api_key,
                        default_headers=build_proxy_headers(agent_id, usage_scope),
                        max_retries=0,
                    ),
                    strategy=strategy,
                    ranked_models=[m for m in available_models if not m.endswith("-image")] or available_models,
                    agent_id=agent_id,
                    task=(
                        f"Image challenge ({challenge.challenge_type}). Instruction: {prompt_text}\n"
                        f"Input image: {'provided (pass it as image_uri)' if challenge.input_image_uri else 'none'}"
                        + (f"\nInput image URI: {challenge.input_image_uri}" if challenge.input_image_uri and len(challenge.input_image_uri) < 500 else "")
                    ),
                    extra_context="",
                    remaining_s=float(challenge.max_time_s or 120) - (time.time() * 1000 - start_ms) / 1000,
                    skip_tools=("arena.image.get_challenge",),
                    exclude_tools=("arena.image.broadcast_thought",),
                    answer_hint=(
                        "Produce the requested image with this server's tools, then call final_answer with the "
                        "image reference it returned (image_ref:img_N) or its URL."
                    ),
                    budget_fraction=0.7,
                    post_async=post_async,
                    http_client=http_client,
                )
                if produced is not None and produced.answer:
                    produced_uri = produced.images.get(produced.answer.strip(), produced.answer.strip())
                    if produced_uri.startswith(("data:image", "http://", "https://")):
                        tool_result = {"image_uri": produced_uri}
                        selected_tool = "explorer"

            if tool_result.get("error"):
                print(f"   Tool warning: {tool_result.get('error')}")

            output_image_uri = str(tool_result.get("image_uri") or "").strip()
            if not output_image_uri and challenge.input_image_uri:
                output_image_uri = challenge.input_image_uri
            if not output_image_uri:
                if mcp_session_dead:
                    await session_monitor.stop()
                    raise RuntimeError(
                        "Image MCP tool failed and no input_image_uri is available "
                        "to submit; refusing to invent image bytes"
                    )
                output_image_uri = BLANK_PNG_DATA_URI

            total_time_ms = int(time.time() * 1000 - start_ms)
            await _stop_metrics_reporter()
            wait_posted()
            client_metrics = {
                "model_name": model_name,
                "planner_tool": selected_tool,
                "total_tokens": str(live_total_tokens),
                "prompt_tokens": str(live_prompt_tokens),
                "completion_tokens": str(live_completion_tokens),
                "ttft_ms": 0,
                "total_time_ms": total_time_ms,
            }
            if mcp_session_dead:
                await session_monitor.stop()
                print("   MCP session unavailable; submitting image over REST")
                image_submit_result = _submit_with_retry(
                    http_client,
                    agent_id,
                    answer=output_image_uri,
                    client_metrics=client_metrics,
                    challenge_type="image",
                )
            else:
                image_submit_result = await mcp_client.submit_image(
                    agent_id=agent_id,
                    image_uri=output_image_uri,
                    client_metrics=client_metrics,
                    rationale="simple_agent dynamic image flow",
                )
            for line in submission_summary_lines(image_submit_result):
                print(f"   {line}")
            await session_monitor.stop()
            # Last steps, after the submission is final; neither raises.
            print(f"   Image: {save_submitted_image(agent_id, output_image_uri, REPO_ROOT)}")
            if isinstance(image_submit_result, dict):
                image_result = image_submit_result
            else:  # REST fallback returns a SubmitResult
                image_result = {
                    "accepted": getattr(image_submit_result, "accepted", None),
                    "score": getattr(image_submit_result, "score", None),
                }
            score = image_result.get("score") if isinstance(image_result.get("score"), dict) else {}
            run_record = {
                "agent_id": agent_id,
                "challenge": challenge_record(challenge),
                "model": model_name,
                "image_tool_sequence": image_tool_sequence,
                "result": {
                    "accepted": image_result.get("accepted"),
                    "score": {key: value for key, value in score.items() if key != "output_image_uri"},
                },
            }
            print(f"   Run record: {save_run_record(agent_id, run_record, REPO_ROOT)}")
            print("\n✅ Agent completed!")
            return

        # The roster does not depend on the challenge: fetch it off the clock.
        models_task = asyncio.create_task(asyncio.to_thread(fetch_available_models, llm_host, llm_api_key))
        # Wait for organizer to start (challenge is locked while lobby is open)
        challenge = None
        while "arena.get_challenge" in tools:
            try:
                challenge = await mcp_client.get_challenge(agent_id)
                break
            except McpArenaError as e:
                message = str(e).lower()
                if "locked" in message or "waiting for organizer" in message:
                    print("   Lobby open; waiting for organizer to start battle...")
                    await asyncio.sleep(3.0)
                else:
                    # A black box may hide the brief elsewhere: explore for it.
                    print(f"   ⚠️  arena.get_challenge failed ({e}); exploring for the brief instead.")
                    break
        if challenge is None:
            challenge = await _briefless_challenge(mcp_client, agent_id)
        print_challenge(challenge)
        # Everything below until the LLM call is scored time: overlap it.
        post_async(http_client.broadcast_thought, agent_id, "Reading challenge and clues...")
        clues_task = asyncio.create_task(_fetch_clues(mcp_client, agent_id, tools))
        usage_scope, available_models = await asyncio.gather(
            asyncio.to_thread(lambda: http_client.fetch_usage_scope() or resolve_usage_scope()),
            models_task,
        )
        if usage_scope:
            os.environ["ARENA_USAGE_SCOPE"] = usage_scope
        # Bound each LLM call so a hung model leaves time for one fallback model
        # and the submit; the SDK default (600s, 2 retries) outlives any puzzle.
        llm_client = OpenAI(
            base_url=llm_host,
            api_key=llm_api_key,
            default_headers=build_proxy_headers(agent_id, usage_scope),
            timeout=max(10.0, 0.4 * float(challenge.max_time_s or 60)),
            max_retries=0,
        )
        print("   LLM: Enabled")
        print()

        model_ctx = _build_context(
            challenge_type=challenge.challenge_type,
            description=challenge.description,
            rules=challenge.rules,
            max_time_s=challenge.max_time_s,
            available_models=available_models,
        )
        ranked_models = strategy.rank_models(model_ctx, available_models)
        model_name = strategy.pick_model("solve", ranked_models, model_ctx)
        model_name = require_explicit_model(
            model_name,
            available_models,
            source="python_simple agent",
        )
        print(f"   Selected model: {model_name}")
        await _start_metrics_reporter(model_name)

        print("\n📖 Reading clues...")
        clues, clue_tools_called = await clues_task
        if not clues:
            clues = [str(clue_text) for clue_text in challenge.clues]

        tool_evidence_lines = await _enforce_required_tool_calls(
            mcp_client=mcp_client,
            agent_id=agent_id,
            challenge_type=str(challenge.challenge_type or ""),
            description=str(challenge.description or ""),
            rules=str(challenge.rules or ""),
            clues=clues,
            available_tool_names=[str(name) for name in tools],
            http_client=http_client,
            extra_context=str(getattr(challenge, "extra_text", "") or ""),
            already_called={"arena.get_challenge", *clue_tools_called},
        )
        
        # Broadcast thought
        post_async(http_client.broadcast_thought, agent_id, f"Analyzing {len(clues)} clues...")

        # Save draft (backup)
        post_async(http_client.save_draft, agent_id, "Working on solution...")

        # Step 3: Solve
        print("\n🧠 Solving...")
        post_async(http_client.broadcast_thought, agent_id, "Calling LLM...")
        solve_ctx = _build_context(
            challenge_type=challenge.challenge_type,
            description=challenge.description,
            rules=_rules_with_format(challenge),
            clues=clues,
            max_time_s=challenge.max_time_s,
            available_models=ranked_models,
        )

        async def _remaining_s() -> float:
            info = await mcp_client.time_remaining(agent_id)
            return float(info.get("time_remaining_s", 0.0))

        def _solve_with(retry_model: str):
            nonlocal ticker
            post_async(http_client.broadcast_thought, agent_id, f"Retrying with {retry_model}...")
            ticker = ReasoningTicker(retry_model)
            return solve_challenge(
                challenge,
                clues,
                llm_client,
                retry_model,
                strategy,
                solve_ctx,
                http_client=http_client,
                agent_id=agent_id,
                broadcast_thought=True,
                evidence_lines=tool_evidence_lines,
                ticker=ticker,
            )

        explore_why = route_reason(
            [str(name) for name in tools],
            "\n".join([str(challenge.description or ""), str(challenge.rules or ""), *clues, str(getattr(challenge, "extra_text", "") or "")]),
        )
        explored = None
        if explore_why:
            print(f"\n🧭 Explorer engaged: {explore_why}")
            post_async(http_client.broadcast_thought, agent_id, f"Exploring the server: {explore_why}")
            explored = await _run_explorer(
                mcp_client=mcp_client,
                llm_client=llm_client,
                strategy=strategy,
                ranked_models=ranked_models,
                agent_id=agent_id,
                task=_text_task(challenge),
                extra_context="\n".join(
                    [*(f"clue: {c}" for c in clues), *(f"evidence: {e}" for e in tool_evidence_lines)]
                ),
                remaining_s=await _remaining_or_default(mcp_client, agent_id, challenge),
                skip_tools=("arena.get_challenge", "arena.clues.list", "arena.clues.get"),
                exclude_tools=("arena.get_challenge", "arena.clues.list", "arena.clues.get"),
                post_async=post_async,
                http_client=http_client,
            )

        ticker = ReasoningTicker(model_name)
        if explored is not None and explored.answer:
            usage = dict(explored.usage)
            solved = (explored.answer, explored.reason, explored.model or model_name, usage, 0, explored.elapsed_ms)
        else:
            try:
                solved = await solve_challenge(
                    challenge,
                    clues,
                    llm_client,
                    model_name,
                    strategy,
                    solve_ctx,
                    http_client=http_client,
                    agent_id=agent_id,
                    broadcast_thought=True,
                    evidence_lines=tool_evidence_lines,
                    ticker=ticker,
                )
            except Exception as exc:
                # Timeout or upstream error: one try with the next ranked model,
                # else fall through to the fallback answer so we still submit.
                ticker.finish()
                fallback_model = _next_ranked_model(ranked_models, model_name)
                print(f"   ⚠️  {model_name} failed ({type(exc).__name__}); trying {fallback_model or 'no fallback'}.")
                solved = ("", "", model_name, {}, 0, 0)
                if fallback_model:
                    try:
                        solved = await _solve_with(fallback_model)
                    except Exception as retry_exc:
                        print(f"   ⚠️  {fallback_model} failed too ({type(retry_exc).__name__}).")
        ticker.finish()

        answer, raw_response, model_name, usage, ttft_ms, total_time_ms = await _retry_after_length_stop(
            solved,
            ranked_models=ranked_models,
            remaining_s=_remaining_s,
            solve_with=_solve_with,
        )
        ticker.finish()
        for line in summary_lines(
            model=model_name,
            elapsed_s=total_time_ms / 1000,
            usage=usage,
            finish_reason=str(usage.get("finish_reason") or ""),
            answer=answer,
            ticker=ticker,
        ):
            print(line)
        
        if _is_invalid_answer_candidate(answer):
            answer = ""
        if not answer:
            print("   ⚠️  No valid ANSWER format found; using last line as fallback.")
            lines = raw_response.strip().splitlines()
            last_line = lines[-1].strip().strip("`\"'") if lines else ""
            answer = (
                last_line
                if last_line and len(last_line) < 400 and not _is_invalid_answer_candidate(last_line)
                else "unknown"
            )

        # Save draft with extracted answer as backup
        post_async(http_client.save_draft, agent_id, answer, "LLM solution")
        post_async(http_client.broadcast_thought, agent_id, f"Answer: {answer}")
        
        # Check time remaining
        time_info = await mcp_client.time_remaining(agent_id)
        remaining_s = float(time_info.get("time_remaining_s", 0.0))
        submit_ctx = _build_context(
            challenge_type=challenge.challenge_type,
            description=challenge.description,
            rules=challenge.rules,
            clues=clues,
            max_time_s=challenge.max_time_s,
            available_models=ranked_models,
            time_remaining_s=remaining_s,
            tokens_used=usage.get("total_tokens", 0),
        )
        if strategy.should_submit_early(answer, submit_ctx):
            post_async(http_client.broadcast_thought, agent_id, "⚡ Strategy submitting early.")
        revised_answer = strategy.on_time_warning(remaining_s, answer, submit_ctx)
        if isinstance(revised_answer, str) and revised_answer.strip():
            answer = revised_answer.strip()
        print(f"   Time remaining: {time_info['time_remaining_s']:.1f}s")
    
    # Step 4: Submit the extracted answer with real metrics
    print("\n📤 Submitting answer...")
    await _stop_metrics_reporter()
    wait_posted()
    
    result = _submit_with_retry(
        http_client,
        agent_id=agent_id,
        answer=answer,
        client_metrics={
            "model_name": model_name,
            "total_tokens": str(live_total_tokens),
            "prompt_tokens": str(live_prompt_tokens),
            "completion_tokens": str(live_completion_tokens),
            "ttft_ms": ttft_ms,
            "total_time_ms": total_time_ms,
        }
    )
    
    print(f"   Accepted: {result.accepted}")
    print(f"   Status: {result.status}")
    if result.score:
        print(f"   Score: {result.score.get('final_score', 0)}")
        print(f"   Quality: {result.score.get('quality_score', 0)}")
        print(f"   Speed: {result.score.get('speed_score', 0)}")
    if missing_tools_note(result):
        print(f"   ⚠️  {missing_tools_note(result)}")
    
    await session_monitor.stop()
    # Last step, after the submission is final; never raises.
    run_record = {
        "agent_id": agent_id,
        "challenge": challenge_record(challenge),
        "model": model_name,
        "answer": answer,
        "usage": usage,
        "total_time_ms": total_time_ms,
        "result": {
            "accepted": result.accepted,
            "status": result.status,
            "score": result.score,
        },
    }
    print(f"   Run record: {save_run_record(agent_id, run_record, REPO_ROOT)}")
    print("\n✅ Agent completed!")


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except asyncio.CancelledError:
        raise SystemExit(0)
    except ModelSelectionError as exc:
        print(f"   {exc}")
        raise SystemExit(1)
