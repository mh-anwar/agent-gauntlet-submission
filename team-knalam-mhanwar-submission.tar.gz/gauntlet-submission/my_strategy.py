"""Competitor strategy definition for starter-kit agents.

Edit this class to customize behavior without touching runtime code.
"""

from __future__ import annotations

import os
import re

from base_strategy import BaseStrategy, ChallengeContext

# python_simple streams reasoning as one blocking thought POST per ~80 chars,
# which cost ~110s on the hard practice puzzle. Milestone thoughts still post.
os.environ.setdefault("LLM_STREAM", "0")

# Measured on Practice (2026-10-27): gpt-5.6-terra 9/9 logic puzzles in ~4s,
# gpt-5.4 8/9 in ~2s; the roster default nemotron-3.5-lightning failed medium.
# Images, with this file's prompts (n=3-8 each): flash-lite 88.7 edit / 91.0
# generate in ~9s vs pro 88.8 / 89.9 in ~24s -- pro's quality edge is eaten by
# speed. Pro is the fallback when flash-lite returns no image.
# ponytail: static preference list, falls back to roster order for unknown
# aliases; re-benchmark when the event roster is published.
# Explorer (tool-calling) evidence from the black-box benchmark, 8 scenarios
# each: nemotron-3-ultra 8/8, nemotron-3-super 8/8, gpt-5.4/gemini-3.8-flash/
# qwen3.7-max 7/8, nemotron-3.5-lightning 6/8 (loops on failing calls).
TEXT_MODEL_PREFS = (
    "gpt-5.6-terra", "gpt-5.4", "nemotron-3-ultra", "nemotron-3-super", "gemini-3.8-flash", "qwen3.7-max",
)
# One-shot logic solve, 3 Practice puzzles x 3 (2026-10-27): terra default 8/9
# in 4.0s mean; "minimal" 9/9 in 3.1s; "low" 9/9 in 3.9s.
TEXT_REASONING_EFFORT = {"gpt-5.6-terra": "minimal"}
# Unknown rosters (event day): bigger tiers first, small/fast tiers last.
_TIER_PATTERNS = (
    (0, re.compile(r"ultra|opus|max\b|-max|pro\b|-pro|large|405b|70b|terra", re.IGNORECASE)),
    (1, re.compile(r"super|plus|sonnet|medium|\bgpt-5", re.IGNORECASE)),
    (3, re.compile(r"lightning|nano|mini|lite|tiny|small|haiku|flash|\b[0-9]{1,2}b\b|-[0-9]{1,2}b", re.IGNORECASE)),
)


def _tier(model: str) -> int:
    for tier, pattern in _TIER_PATTERNS:
        if pattern.search(model):
            return tier
    return 2
IMAGE_MODEL_PREFS = ("gemini-3.1-flash-lite-image", "gemini-3-pro-image", "gemini-3.1-flash-image")


def _prefer(models: list[str], prefs: tuple[str, ...], *, by_tier: bool = False) -> list[str]:
    """Put preferred aliases first (in pref order); the rest by size tier or roster order."""
    first = [m for m in prefs if m in models]
    rest = [m for m in models if m not in first]
    if by_tier:
        rest.sort(key=_tier)  # stable: roster order within a tier
    return first + rest


class MyStrategy(BaseStrategy):
    """Default competitor strategy template."""

    # Team identity (shown in Organizer/Dashboard)
    agent_id = "team-knalam-mhanwar"
    agent_name = "Team KNalam MHAnwar"

    # Text challenge strategy
    text_system_prompt = (
        "You are a precise puzzle and reasoning solver. "
        "Your first line must always be: ANSWER: <final answer>. "
        "Before answering, check your candidate against every clue and rule; "
        "if any is violated, fix it before you write the ANSWER line. "
        # practice_logic_easy_001 has two valid orders and the judge takes the
        # one in first-mention order: 5/6 -> 6/6 with this tie-break.
        "If more than one answer satisfies every rule and clue, choose the one whose items stay "
        "closest to the order in which they are first mentioned in the challenge and clues. "
        "Follow challenge rules exactly, including strict output formats. "
        "Put the complete answer on that single ANSWER line; if the rules ask for JSON, "
        "write it as compact one-line JSON with no code fences. "
        "Do not output <think> tags. "
        "If you add reasoning, keep it to at most 2 short lines after the ANSWER line. "
        "Never output 'unknown'."
    )
    text_strategy_notes = "Verify against every clue; always include an ANSWER line."
    text_temperature = 0.0
    # Reasoning models spend most of this budget thinking before they answer;
    # 1024 cut the roster's default model off before it wrote an answer.
    text_max_tokens = 8192

    # Image challenge strategy
    image_strategy_notes = (
        "Prefer image_edit when an input image is available. Keep rationale concise. "
        "Request standard-resolution output only and avoid HD or 4K images."
    )

    def reasoning_effort(self, model: str) -> str | None:
        """reasoning_effort for the one-shot text solve (only where measured)."""
        return TEXT_REASONING_EFFORT.get(model)

    def rank_models(self, ctx: ChallengeContext, available_models: list[str]) -> list[str]:
        ranked = super().rank_models(ctx, available_models)
        prefs = IMAGE_MODEL_PREFS if self.is_image_challenge(ctx) else TEXT_MODEL_PREFS
        # Experiments: AGENT_TEXT_MODELS="a,b" puts those first (benchmarking other models).
        override = tuple(m.strip() for m in os.getenv("AGENT_TEXT_MODELS", "").split(",") if m.strip())
        if override and not self.is_image_challenge(ctx):
            prefs = override + prefs
        return _prefer(ranked, prefs, by_tier=not self.is_image_challenge(ctx))

    def build_image_prompt(self, ctx: ChallengeContext) -> str:
        prompt = super().build_image_prompt(ctx)
        if ctx.image_url:
            # Judge "preservation" sat at 68-73 with the stock prompt.
            return (
                f"{prompt}\n\nEdit discipline: change ONLY what the instruction asks for. "
                "Keep the subject's face, identity, expression, pose, camera angle, framing, "
                "lighting, colors, and background exactly as in the input image. "
                "No style transfer, no re-rendering of untouched areas."
            )
        # Judge "constraints" sits at 82-84 on generate (neon signs get pseudo-glyphs).
        # Naming signs/billboards explicitly scored worse (72), so keep this short.
        return (
            f"{prompt}\n\nHard constraints: follow every constraint in the task literally. "
            "No text, letters, numbers, logos, signage, or watermarks anywhere in the image "
            "unless the task explicitly asks for them."
        )


if __name__ == "__main__":
    s = MyStrategy()
    roster = ["nemotron-3.5-lightning", "gpt-5.4", "gpt-5.6-terra", "gemini-3.1-flash-lite-image", "gemini-3-pro-image"]
    assert s.rank_models(ChallengeContext(challenge_type="logic-puzzle"), roster)[:2] == ["gpt-5.6-terra", "gpt-5.4"]
    img = ChallengeContext(challenge_type="image-edit", image_url="x")
    assert s.rank_models(img, roster)[:2] == ["gemini-3.1-flash-lite-image", "gemini-3-pro-image"]
    assert s.rank_models(ChallengeContext(challenge_type="logic"), ["a", "b"]) == ["a", "b"]
    unknown = ["nemo-x-lightning", "nemo-x-ultra", "acme-chat", "acme-super"]
    assert s.rank_models(ChallengeContext(challenge_type="logic"), unknown) == [
        "nemo-x-ultra", "acme-super", "acme-chat", "nemo-x-lightning"]
    assert "change ONLY" in s.build_image_prompt(img)
    assert "No text" in s.build_image_prompt(ChallengeContext(challenge_type="image-generate"))
    print("ok")
